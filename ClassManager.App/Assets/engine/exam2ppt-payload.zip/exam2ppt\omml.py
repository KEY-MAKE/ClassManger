# -*- coding: utf-8 -*-
"""Word 原生公式（OMML）→ 线性文本 / 富文本。

理科试卷的公式有两种存法：

  1. **图片**——Word 里就是一张 PNG。这种一直支持，会当作行内插图排进去；
  2. **Word 自带公式**——XML 里是 `<m:oMath>`。这种以前是**整块丢弃**的，
     因为 `python-docx` 的 `paragraph.text` 只认 `<w:t>`，不看 `<m:t>`。
     结果题干会变成「1．设集合，，则（  ）」——公式位置全空，
     选项也整条消失。

本模块把 `<m:oMath>` 翻译成线性文本：

    分式   a/b          （分子分母里有加减号时自动加括号 → (a+b)/c）
    根式   √3、√(a+b)   （根号下是一整个式子才加括号）
    上标   x²、a^(6-2r)  （能换成 Unicode 上标的就直接换）
    下标   aₙ、aₙ₊₁      （同上）
    求和   ∑(k=1→n)k²
    矩阵   [a，b；c，d]

并且**顶层**的上下标会保留成富文本分段（见 richtext.py），
到 PowerPoint 里用 `baseline` 属性渲染成真正的上标下标，而不是靠 Unicode 凑。
嵌套在分式/根式内部的上下标则线性化，避免结构过度复杂。

原则：认不出的结构一律「原样往下递归、把文字拼起来」，绝不返回空字符串——
宁可排版朴素，也不能让公式凭空消失。
"""

import re
from typing import List, Optional

M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_M_PREFIX = "{%s}" % M_NS

from .richtext import Rich, Seg, map_script   # noqa: E402


def M(tag: str) -> str:
    return _M_PREFIX + tag


def W(tag: str) -> str:
    return "{%s}%s" % (W_NS, tag)


def _local(el) -> str:
    tag = el.tag
    if not isinstance(tag, str):
        return ""
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _is_math(el) -> bool:
    tag = el.tag
    return isinstance(tag, str) and tag.startswith(_M_PREFIX)


def _kid(el, name: str):
    if el is None:
        return None
    for c in el:
        if c.tag == M(name):
            return c
    return None


def _kids(el, name: str):
    if el is None:
        return []
    return [c for c in el if c.tag == M(name)]


def _val(pr, name: str, default: str = "") -> str:
    """读属性子元素的 m:val，例如 <m:begChr m:val="["/>。"""
    if pr is None:
        return default
    for c in pr:
        if _local(c) != name:
            continue
        v = c.get(M("val"))
        if v is None:
            v = c.get(W("val"))
        return default if v is None else v
    return default


def _flag(pr, name: str) -> bool:
    return _val(pr, name, "").lower() in ("1", "on", "true")


# --------------------------------------------------------------------------
# 线性化小工具
# --------------------------------------------------------------------------
_PAIRS = {"(": ")", "[": "]", "{": "}", "\u3008": "\u3009",
          "\uff08": "\uff09", "\u3010": "\u3011", "|": "|"}
# 出现这些符号就说明不止一个「项」，当分子/分母时要加括号。
# 斜杠必须算进去：分母本身是分式时（1/(1/x)），不加括号就变成了 1/1/x。
_NEED_PAREN = re.compile(
    r"[+\-\u2212\u00b1=\u2260<>\u2264\u2265\u00d7\u00f7,;\u3001:\uff1a/\u2044]")
_RAD_SIMPLE = re.compile(r"^[0-9A-Za-z.\u0370-\u03ff\u221a]+$")


def _is_wrapped(s: str) -> bool:
    """s 是不是被一对括号完整包住（括号配对且不提前闭合）。"""
    if len(s) < 2:
        return False
    close = _PAIRS.get(s[0])
    if not close or s[-1] != close:
        return False
    depth = 0
    for i, ch in enumerate(s):
        if ch == s[0]:
            depth += 1
        elif ch == close:
            depth -= 1
            if depth == 0 and i != len(s) - 1:
                return False
    return depth == 0


def _paren(s: str) -> str:
    if not s or _is_wrapped(s):
        return s
    return "(" + s + ")" if _NEED_PAREN.search(s) else s


def _rad_body(s: str) -> str:
    if not s or _is_wrapped(s) or _RAD_SIMPLE.match(s):
        return s
    return "(" + s + ")"


def _script(s: str, kind: str) -> str:
    """把一段文字写成上/下标：能换 Unicode 就换，否则 ^(...) / _(...)。"""
    if not s:
        return ""
    mapped = map_script(s, kind)
    if mapped is not None:
        return mapped
    return ("^" if kind == "sup" else "_") + "(" + s + ")"


# --------------------------------------------------------------------------
# 各类 OMML 结构的线性化
# --------------------------------------------------------------------------
def _h_frac(el):
    a = _flat(_kid(el, "num"))
    b = _flat(_kid(el, "den"))
    typ = _val(_kid(el, "fPr"), "type", "bar")
    if typ == "lin":
        return a + "/" + b
    return _paren(a) + "/" + _paren(b)


def _h_rad(el):
    pr = _kid(el, "radPr")
    deg = "" if _flag(pr, "degHide") else _flat(_kid(el, "deg")).strip()
    body = _flat(_kid(el, "e"))
    if not deg or deg == "2":
        sym = "\u221a"
    elif deg == "3":
        sym = "\u221b"
    elif deg == "4":
        sym = "\u221c"
    else:
        sym = "\u221a[" + deg + "]"
    return sym + _rad_body(body)


def _h_delim(el):
    pr = _kid(el, "dPr")
    beg = _val(pr, "begChr", "(")
    end = _val(pr, "endChr", ")")
    sep = _val(pr, "sepChr", "|")
    parts = [_flat(e) for e in _kids(el, "e")]
    return beg + sep.join(parts) + end


def _h_nary(el):
    pr = _kid(el, "naryPr")
    chr_ = _val(pr, "chr", "\u222b")
    sub = "" if _flag(pr, "subHide") else _flat(_kid(el, "sub")).strip()
    sup = "" if _flag(pr, "supHide") else _flat(_kid(el, "sup")).strip()
    body = _flat(_kid(el, "e"))
    head = chr_
    if sub and sup:
        head += "(" + sub + "\u2192" + sup + ")"
    elif sub:
        head += "(" + sub + ")"
    elif sup:
        head += "(" + sup + ")"
    return head + body


def _h_func(el):
    name = _flat(_kid(el, "fName"))
    arg = _flat(_kid(el, "e"))
    if not arg:
        return name
    return name + (arg if _is_wrapped(arg) else "(" + arg + ")")


def _h_lim(el):
    ln = _local(el)
    base = _flat(_kid(el, "e"))
    lim = _flat(_kid(el, "lim")).strip()
    if not lim:
        return base
    return base + _script(lim, "sub" if ln == "limLow" else "sup")


def _h_sup(el):
    return _flat(_kid(el, "e")) + _script(_flat(_kid(el, "sup")), "sup")


def _h_sub(el):
    return _flat(_kid(el, "e")) + _script(_flat(_kid(el, "sub")), "sub")


def _h_subsup(el):
    return (_flat(_kid(el, "e")) + _script(_flat(_kid(el, "sub")), "sub")
            + _script(_flat(_kid(el, "sup")), "sup"))


def _h_pre(el):
    return (_script(_flat(_kid(el, "sub")), "sub")
            + _script(_flat(_kid(el, "sup")), "sup")
            + _flat(_kid(el, "e")))


def _h_matrix(el):
    rows = []
    for mr in _kids(el, "mr"):
        rows.append("\uff0c".join(_flat(e) for e in _kids(mr, "e")))
    return "[" + "\uff1b".join(r for r in rows if r) + "]"


def _h_eqarr(el):
    rows = [_flat(e) for e in _kids(el, "e")]
    return "\uff1b".join(r for r in rows if r)


def _with_accent(body: str, mark: str) -> str:
    """给文字加一个组合符号（上划线、向量箭头、帽子）。

    组合符号只能压在一个字符上。单个字符时最准；多个字符时宁可不加，
    也不要把符号压在最后一个字上造成误读。
    """
    if not body or not mark:
        return body
    if len(body) == 1:
        return body + mark
    return body


def _h_bar(el):
    pr = _kid(el, "barPr")
    pos = _val(pr, "pos", "top")
    return _with_accent(_flat(_kid(el, "e")), "\u0332" if pos == "bot"
                        else "\u0305")


def _h_acc(el):
    pr = _kid(el, "accPr")
    return _with_accent(_flat(_kid(el, "e")), _val(pr, "chr", "\u0302"))


def _h_phant(el):
    if _flag(_kid(el, "phantPr"), "show"):
        return _flat(_kid(el, "e"))
    # 默认 show 是开的，只有显式 show="0" 才隐藏
    return "" if _val(_kid(el, "phantPr"), "show", "1") in ("0", "off", "false") \
        else _flat(_kid(el, "e"))


_HANDLERS = {
    "f": _h_frac,
    "rad": _h_rad,
    "d": _h_delim,
    "nary": _h_nary,
    "func": _h_func,
    "limLow": _h_lim,
    "limUpp": _h_lim,
    "sSup": _h_sup,
    "sSub": _h_sub,
    "sSubSup": _h_subsup,
    "sPre": _h_pre,
    "m": _h_matrix,
    "eqArr": _h_eqarr,
    "bar": _h_bar,
    "acc": _h_acc,
    "groupChr": lambda el: _flat(_kid(el, "e")),
    "box": lambda el: _flat(_kid(el, "e")),
    "borderBox": lambda el: _flat(_kid(el, "e")),
    "phant": _h_phant,
}


def _flat(el) -> str:
    """完整线性化成一段文字。"""
    if el is None:
        return ""
    if el.tag == M("t"):
        return el.text or ""
    fn = _HANDLERS.get(_local(el))
    if fn is not None:
        return fn(el)
    # 兜底：按顺序拼接所有数学子节点（m:r、m:e、各种 Pr 都走这里）
    return "".join(_flat(c) for c in el if _is_math(c))


# --------------------------------------------------------------------------
# 顶层：把上下标保留成分段
# --------------------------------------------------------------------------
def _node_segs(el) -> List[Seg]:
    ln = _local(el)

    if ln == "sSup":
        return [(_flat(_kid(el, "e")), ""),
                (_flat(_kid(el, "sup")), "sup")]
    if ln == "sSub":
        return [(_flat(_kid(el, "e")), ""),
                (_flat(_kid(el, "sub")), "sub")]
    if ln == "sSubSup":
        return [(_flat(_kid(el, "e")), ""),
                (_flat(_kid(el, "sub")), "sub"),
                (_flat(_kid(el, "sup")), "sup")]
    if ln == "sPre":
        return [(_flat(_kid(el, "sub")), "sub"),
                (_flat(_kid(el, "sup")), "sup"),
                (_flat(_kid(el, "e")), "")]
    if ln == "nary":
        pr = _kid(el, "naryPr")
        segs: List[Seg] = [(_val(pr, "chr", "\u222b"), "")]
        if not _flag(pr, "subHide"):
            segs.append((_flat(_kid(el, "sub")), "sub"))
        if not _flag(pr, "supHide"):
            segs.append((_flat(_kid(el, "sup")), "sup"))
        segs.append((_flat(_kid(el, "e")), ""))
        return segs
    if ln in ("limLow", "limUpp"):
        return [(_flat(_kid(el, "e")), ""),
                (_flat(_kid(el, "lim")), "sub" if ln == "limLow" else "sup")]
    return [(_flat(el), "")]


_CONTAINERS = ("oMath", "oMathPara")


def omml_segments(el) -> List[Seg]:
    """<m:oMath> / <m:oMathPara> → 分段列表。"""
    ln = _local(el)
    if ln in _CONTAINERS:
        out: List[Seg] = []
        for c in el:
            if _is_math(c) and _local(c) not in ("oMathParaPr", "oMathPr"):
                out.extend(omml_segments(c))
        return out
    return _node_segs(el)


# --------------------------------------------------------------------------
# 段落级接口
# --------------------------------------------------------------------------
_SKIP = {W("pPr"), W("rPr"), W("instrText"), W("delText"), W("del"),
         W("moveFrom"), W("footnoteReference"), W("endnoteReference"),
         W("commentReference")}


def has_math(p_el) -> bool:
    """段落里有没有 Word 原生公式。"""
    for el in p_el.iter():
        if el.tag in (M("oMath"), M("oMathPara")):
            return True
    return False


def para_segments(p_el) -> List[Seg]:
    """按文档顺序把一段拆成分段：正文文字 + 公式。"""
    segs: List[Seg] = []

    def walk(el):
        for ch in el:
            tag = ch.tag
            if tag in (M("oMath"), M("oMathPara")):
                segs.extend(omml_segments(ch))
                continue
            if tag == W("t"):
                segs.append((ch.text or "", ""))
                continue
            if tag in _SKIP:
                continue
            if tag == W("tab"):
                segs.append(("\t", ""))
                continue
            if tag in (W("br"), W("cr")):
                segs.append(("\n", ""))
                continue
            walk(ch)

    walk(p_el)
    return segs


def para_text(p_el, fallback: str) -> str:
    """段落的文字：有公式就返回 Rich，没有就返回现成的纯文本。"""
    if not has_math(p_el):
        return fallback
    return Rich(para_segments(p_el))
