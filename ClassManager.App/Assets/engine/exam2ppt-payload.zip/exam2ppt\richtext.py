# -*- coding: utf-8 -*-
"""带上下标的富文本。

理科试卷里的公式没法靠纯文本表达：`aₙ₊₁` 里的 n+1 必须是下标，`x^(6-2r)`
里的指数必须抬高。做法是把一段文字表示成**分段序列**，每段标记它是正常、
上标还是下标：

    Rich([("a", ""), ("n+1", "sub")])

关键设计：`Rich` 是 `str` 的子类，`str(Rich(...))` 就是可以直接读的纯文本
（能上标的字符自动换成 Unicode 上标，例如 `aₙ₊₁`）。这样一来：

  · 正则匹配、字数统计、折行测量这些代码**一行都不用改**，照旧按字符串处理；
  · 到真正写 PowerPoint 时才展开 `.segs`，用 `baseline` 属性做成真正的上下标；
  · 万一某个环节把 Rich 降级成了普通字符串，输出只是丢了上下标，
    不会出现乱码或占位符。这就是「优雅降级」。
"""

from typing import Iterable, List, Optional, Sequence, Tuple

Seg = Tuple[str, str]          # (文本, '': 正常 / 'sup': 上标 / 'sub': 下标)

# 能直接换成 Unicode 上下标的字符。中文字体未必收录这些码位，
# 但 PowerPoint 会做字体回退，实测显示正常，所以拿来当纯文本的兜底表示。
SUP_MAP = {
    "0": "\u2070", "1": "\u00b9", "2": "\u00b2", "3": "\u00b3", "4": "\u2074",
    "5": "\u2075", "6": "\u2076", "7": "\u2077", "8": "\u2078", "9": "\u2079",
    "+": "\u207a", "-": "\u207b", "\u2212": "\u207b", "=": "\u207c",
    "(": "\u207d", ")": "\u207e", "n": "\u207f", "i": "\u2071",
    "a": "\u1d43", "b": "\u1d47", "c": "\u1d9c", "d": "\u1d48", "e": "\u1d49",
    "f": "\u1da0", "g": "\u1d4d", "h": "\u02b0", "j": "\u02b2", "k": "\u1d4f",
    "l": "\u02e1", "m": "\u1d50", "o": "\u1d52", "p": "\u1d56", "r": "\u02b3",
    "s": "\u02e2", "t": "\u1d57", "u": "\u1d58", "v": "\u1d5b", "w": "\u02b7",
    "x": "\u02e3", "y": "\u02b8", "z": "\u1dbb",
}
SUB_MAP = {
    "0": "\u2080", "1": "\u2081", "2": "\u2082", "3": "\u2083", "4": "\u2084",
    "5": "\u2085", "6": "\u2086", "7": "\u2087", "8": "\u2088", "9": "\u2089",
    "+": "\u208a", "-": "\u208b", "\u2212": "\u208b", "=": "\u208c",
    "(": "\u208d", ")": "\u208e",
    "a": "\u2090", "e": "\u2091", "o": "\u2092", "x": "\u2093",
    "h": "\u2095", "k": "\u2096", "l": "\u2097", "m": "\u2098", "n": "\u2099",
    "p": "\u209a", "s": "\u209b", "t": "\u209c",
}


def map_script(text: str, kind: str) -> Optional[str]:
    """整段都能换成 Unicode 上下标就返回换好的，有一个换不了就返回 None。"""
    table = SUP_MAP if kind == "sup" else SUB_MAP
    out = []
    for ch in text:
        if ch == " ":
            out.append(ch)
            continue
        mapped = table.get(ch)
        if mapped is None:
            return None
        out.append(mapped)
    return "".join(out)


def _plain_of(text: str, kind: str) -> str:
    """一段文字在纯文本里长什么样。"""
    if not kind:
        return text
    mapped = map_script(text, kind)
    return mapped if mapped is not None else text


class Rich(str):
    """带上下标分段的字符串。"""

    __slots__ = ("segs",)

    def __new__(cls, segs: Sequence[Seg]):
        merged: List[Seg] = []
        for text, kind in segs:
            if not text:
                continue
            if merged and merged[-1][1] == kind:
                merged[-1] = (merged[-1][0] + text, kind)
            else:
                merged.append((text, kind))
        obj = str.__new__(cls, "".join(_plain_of(t, k) for t, k in merged))
        obj.segs = merged
        return obj

    # ---- 让常见字符串操作也保留格式 ----
    def __add__(self, other):
        return rich_concat(self, other)

    def __radd__(self, other):
        return rich_concat(other, self)

    def strip(self, chars=None):
        return strip_rich(self, chars)

    def lstrip(self, chars=None):
        return _slice_keep(self, _lead_cut(self, chars), len(self))

    def rstrip(self, chars=None):
        return _slice_keep(self, 0, _trail_cut(self, chars))

    def has_script(self) -> bool:
        return any(k for _, k in self.segs)


def _slice_keep(x, a, b):
    if not isinstance(x, Rich):
        return x[a:b]
    return slice_rich(x, a, b)


def _lead_cut(x, chars=None) -> int:
    """开头被裁掉几个字符。"""
    n = len(x)
    if chars is None:
        return n - len(str.lstrip(x))
    return n - len(str.lstrip(x, chars))


def _trail_cut(x, chars=None) -> int:
    """保留到第几个字符（不含尾部空白）。"""
    if chars is None:
        return len(str.rstrip(x))
    return len(str.rstrip(x, chars))


def strip_rich(x, chars=None) -> str:
    if not isinstance(x, Rich):
        return x.strip() if chars is None else x.strip(chars)
    start = _lead_cut(x, chars)
    end = _trail_cut(x, chars)
    if start >= end:
        return Rich([])
    return slice_rich(x, start, end)


def slice_rich(x, a: int, b: Optional[int] = None) -> str:
    """按**纯文本下标**切片，同时把分段一起切好。"""
    n = len(x)
    if not isinstance(x, Rich):
        return x[a:b]
    a = 0 if a is None else max(0, a)
    b = n if b is None else min(b, n)
    if a >= b:
        return Rich([])
    out: List[Seg] = []
    pos = 0
    for text, kind in x.segs:
        s, e = pos, pos + len(_plain_of(text, kind))
        pos = e
        lo, hi = max(a, s), min(b, e)
        if lo >= hi:
            continue
        if kind and lo == s and hi == e:
            out.append((text, kind))          # 整段都在范围内，保留上下标
        elif kind:
            # 被切开的上标/下标：退化成普通文字，也比错位好
            out.append((text[lo - s:hi - s], ""))
        else:
            out.append((text[lo - s:hi - s], ""))
    return Rich(out)


def split_rich(x, sep: str = "\n") -> List[str]:
    """按分隔符切开，每截都保留格式。"""
    if not isinstance(x, Rich):
        return x.split(sep)
    parts: List[str] = []
    start = 0
    while True:
        i = str.find(x, sep, start)
        if i < 0:
            break
        parts.append(slice_rich(x, start, i))
        start = i + len(sep)
    parts.append(slice_rich(x, start, len(x)))
    return parts


def rich_concat(*parts) -> str:
    """拼接字符串；只要有一段带格式，结果就带格式。"""
    if not any(isinstance(p, Rich) for p in parts):
        return "".join(str(p) for p in parts if p)
    segs: List[Seg] = []
    for p in parts:
        if not p:
            continue
        if isinstance(p, Rich):
            segs.extend(p.segs)
        else:
            segs.append((str(p), ""))
    return Rich(segs)


def has_script(x) -> bool:
    return isinstance(x, Rich) and x.has_script()


def merge_segs(groups: Iterable[Sequence[Seg]]) -> str:
    out: List[Seg] = []
    for g in groups:
        out.extend(g)
    return Rich(out)
