# -*- coding: utf-8 -*-
"""版式常量：颜色、字体、尺寸。

配色与字体直接取自样例讲评课件（《2026 年高考全国二卷语文讲评课件》）的主题，
改这里即可整体换肤。
"""

from pptx.dml.color import RGBColor
from pptx.util import Inches

# ---------------- 画布 ----------------
SLIDE_W_IN = 13.3333
SLIDE_H_IN = 7.5

# ---------------- 颜色 ----------------
RED_DARK = RGBColor(0xA4, 0x00, 0x1F)     # 标签框描边/文字
RED_TITLE = RGBColor(0xC0, 0x00, 0x00)    # 大标题
RED_ANSWER = RGBColor(0xFF, 0x00, 0x00)   # 正确选项
PURPLE = RGBColor(0x70, 0x30, 0xA0)       # 解析正文
BROWN = RGBColor(0xD4, 0x77, 0x46)        # 解析框描边
CREAM_TOP = RGBColor(0xFF, 0xFA, 0xEB)    # 解析框渐变起
CREAM_BOTTOM = RGBColor(0xFD, 0xED, 0xD7) # 解析框渐变止
CARD = RGBColor(0xFF, 0xFF, 0xFF)         # 题卡
INK = RGBColor(0x1A, 0x1A, 0x1A)          # 正文黑
GRAY = RGBColor(0x59, 0x59, 0x59)         # 次要文字
GOLD = RGBColor(0xF4, 0xB1, 0x83)         # 目录序号
NAVY = RGBColor(0x52, 0x37, 0xAB)         # 目录竖排标题
CREAM_NAV = RGBColor(0xFB, 0xF3, 0xDC)    # 目录底色块
CHIP_BG = RGBColor(0xFF, 0xF2, 0xF2)      # 答案标签底
LINE_SOFT = RGBColor(0xE3, 0xE3, 0xE3)

# ---------------- 字体 ----------------
# 全部取中文 Windows / Office 一定自带的字体。
# 注意：样例课件里目录条目和作文范文用的是「方正北魏楷书_GBK」，那是商业字体，
# 本机都没装（样例本身也在用替换字体渲染），所以这里换成系统自带的楷体。
FONT_TITLE = "华文中宋"      # 封面 / 章节大标题 / 目录标题
FONT_STEM = "黑体"           # 题干、选项、左上角标签
FONT_BODY = "楷体"           # 材料正文、导语、目录条目
FONT_UI = "微软雅黑"         # 答案、解析、页码、目录序号

# ---------------- 字号 ----------------
# 「参考」列是样例讲评课件《2026 年高考全国二卷语文高考真题+讲评课件》里实测的值。
# 样例自己并不完全统一（题干 24/26/28 混用、解析 20~28 混用），
# 下面取的是各自出现最多 / 居中的那个值。
SIZE_TAG = 20            # 左上角标签        参考：黑体 20（63 处，完全统一）
SIZE_MATERIAL = 24       # 材料、作文正文     参考：楷体 24（材料页出现最多）
SIZE_GUIDE = 26          # 导语              参考：楷体 26
SIZE_STEM = 24           # 题干与选项         参考：黑体 24 / 26 / 28，取出现最多的 24
SIZE_ANSWER = 24         # 答案、解析         参考：微软雅黑 22 / 24 居多
# 答案太长、一屏放不下时，允许把答案字号往下收一档。
# 这不是自创：样例里最长的那些解析就是用 20~22pt 排的（短解析才用 24~28pt），
# 收小的下限 20pt 正好是样例解析用过的最小字号，不会比样例更小。
ANSWER_SIZES = (24, 22, 20)
SIZE_COVER_SUB = 32      # 封面副标题         参考：华文中宋 32
SIZE_COVER = 60          # 封面主标题         参考：华文中宋 60
SIZE_SECTION = 96        # 章节大标题         参考：华文中宋 96
SIZE_TOC_NO = 28         # 目录序号           参考：微软雅黑 28
SIZE_TOC_ITEM = 48       # 目录条目           参考：48
SIZE_TOC_TITLE = 96      # 目录「目 录」      参考：华文中宋 96
SIZE_PAGENO = 20         # 页码              样例没有页码，取体系里最小的 20

# ---------------- 布局 ----------------
# 文字区对齐样例：样例的正文框是 x=18~19pt、宽 900~927pt、上边 55~61pt、下边约 530pt
# （页面 960×540pt）。这里把题卡放宽、内边距收窄，让换行位置和样例接近。
PAGE_W = 13.3333
MARGIN = 0.40

TAG_X, TAG_Y, TAG_H = 0.16, 0.10, 0.54
CARD_X, CARD_Y = 0.28, 0.76
CARD_W, CARD_H = 12.77, 6.30
PAD_X = 0.18                 # 卡片内左右留白
PAD_Y = 0.20
TEXT_X = CARD_X + PAD_X
TEXT_Y = CARD_Y + PAD_Y
TEXT_W = CARD_W - PAD_X * 2      # 12.41in ≈ 893pt，样例是 900~927pt
TEXT_H = CARD_H - PAD_Y * 2 - 0.05

# ---------------- 题目页：题卡 + 底部悬浮答案面板 ----------------
# 一页里放「题目 + 答案」两块：题目在上，答案面板贴着页面底部悬浮，
# 单击才淡入浮现。下面这些数字决定两块怎么分这一页的高度。
CARD_TOP = 0.76                 # 题卡上边缘
CARD_PAD = 0.18                 # 题卡文字与卡片边的留白
CARD_FULL_BOTTOM = 7.24         # 没有答案面板时，题卡下边缘
CARD_MIN_H = 2.30               # 卡片按内容收高时的下限，免得只剩一条纸带
PANEL_X, PANEL_W = 0.50, 12.33  # 面板比题卡窄一点，视觉上像浮在题卡上
PANEL_BOTTOM = 7.32             # 面板下边缘
PANEL_OVERLAP = 0.20            # 面板压住题卡底部的深度
PANEL_PAD_X = 0.22              # 面板内左右留白
PANEL_PAD_Y = 0.20              # 面板内上下留白
PANEL_GAP = 0.12                # 面板顶与题卡文字的间距

PANEL_MIN = 1.60                # 答案面板最小高度
PANEL_MAX = 4.60                # 答案面板最大高度（保证题目至少还有约 1.6in）
CARD_TEXT_MIN = 1.60            # 题目至少要占的高度


# ============================================================================
# 双主题：文科（语文，深红金）/ 理科（数学，深藏蓝）
# ============================================================================
#
# 理科配色取自用户提供的《第七章 培优专题九 球的切、接问题》讲评课件：
#   · 主色 #0E3178（深藏蓝），封面/章节标题都用它
#   · 白底，内容区宽 12.3in，几乎满宽
#   · 封面主标题 44pt / 副标题 40pt，章节标题 60pt（比语文那套 96pt 小很多）
#
# 用法：流程开始时调用 theme.use("science") 或 theme.use("liberal")。
# builder.py 里全部是 `T.XXX` 形式的模块级访问，所以直接改模块全局变量即可整体换肤，
# 不用改那 1100 行的排版逻辑。

_SCIENCE_OVERRIDES = {
    # ---- 颜色：深藏蓝系 ----
    "RED_DARK":    RGBColor(0x0E, 0x31, 0x78),   # 主色（PPT 实测）
    "RED_TITLE":   RGBColor(0x0E, 0x31, 0x78),   # 大标题
    "RED_ANSWER":  RGBColor(0xC0, 0x00, 0x00),   # 正确选项仍用红（对错要一眼看出）
    "PURPLE":      RGBColor(0x1B, 0x4F, 0x8A),   # 解析正文：中蓝，比正文浅一档
    "BROWN":       RGBColor(0x2E, 0x6D, 0xA4),   # 解析框描边：浅蓝
    "CREAM_TOP":   RGBColor(0xF2, 0xF6, 0xFB),   # 解析框渐变起（冷白）
    "CREAM_BOTTOM": RGBColor(0xE1, 0xEA, 0xF6),  # 渐变止
    "GOLD":        RGBColor(0x4A, 0x7E, 0xB8),   # 目录序号
    "NAVY":        RGBColor(0x0E, 0x31, 0x78),   # 目录竖排标题
    "CREAM_NAV":   RGBColor(0xEC, 0xF2, 0xFA),   # 目录底色块
    "CHIP_BG":     RGBColor(0xEC, 0xF3, 0xFC),   # 答案标签底
    "LINE_SOFT":   RGBColor(0xDC, 0xE4, 0xEF),

    # ---- 字体：理科偏端正，正文不用楷体 ----
    "FONT_TITLE":  "华文中宋",   # 封面/章节保持宋体骨架，和 PPT 观感一致
    "FONT_STEM":   "宋体",       # 题干用宋体：数理公式、希腊字母在宋体下更规整
    "FONT_BODY":   "宋体",       # 材料正文
    "FONT_UI":     "微软雅黑",   # 答案/解析/页码

    # ---- 字号：整体比语文那套收一档（PPT 实测 44/40/60） ----
    "SIZE_TAG":        18,
    "SIZE_MATERIAL":   22,
    "SIZE_GUIDE":      22,
    "SIZE_STEM":       22,
    "SIZE_ANSWER":     22,
    "SIZE_COVER_SUB":  28,
    "SIZE_COVER":      44,   # PPT 实测 40~44
    "SIZE_SECTION":    60,   # PPT 实测 60
    "SIZE_TOC_NO":     24,
    "SIZE_TOC_ITEM":   40,
    "SIZE_TOC_TITLE":  60,
    "SIZE_PAGENO":     18,
}

# 记录默认（文科）值，方便切回来
_LITERAL_DEFAULTS = {k: globals()[k] for k in _SCIENCE_OVERRIDES}
_CURRENT_STYLE = "liberal"


def use(style: str) -> str:
    """切换主题。style = "liberal"（默认，文科）| "science"（理科）。

    返回实际生效的 style。任何无法识别的值都退回 liberal。
    """
    global _CURRENT_STYLE
    key = (style or "").strip().lower()

    if key in ("science", "sci", "理科", "math", "理"):
        for k, v in _SCIENCE_OVERRIDES.items():
            globals()[k] = v
        _CURRENT_STYLE = "science"
    else:
        for k, v in _LITERAL_DEFAULTS.items():
            globals()[k] = v
        _CURRENT_STYLE = "liberal"

    return _CURRENT_STYLE


def current() -> str:
    return _CURRENT_STYLE
