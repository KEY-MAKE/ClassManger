# -*- coding: utf-8 -*-
"""文本度量与小工具：估算行宽、按版面分页、清洗标题。

字体度量的核心是一个经验公式：中文全角字符占 1 个字宽，西文/数字占 0.5。
PowerPoint 里文本框是自动换行的，所以这里只要估得准一点，保证内容不溢出、
不出现"孤行"即可，不追求逐像素精确。
"""

import re
import unicodedata
from typing import List

# 单字宽度按「字号（em）」折算。
# 中文标点（「，」「。」）、弯引号（“”）、破折号（——）在 CJK 环境里都按全角排，
# 用 unicodedata 的东亚宽度表判断最稳妥：W/F/A 视为全角，其余按半角。
_CHAR_MARGIN = 1.03      # 全角字符实际字身宽度略大于 1em，留 3% 余量
_WIDE_EAW = ("W", "F", "A")


def char_width(ch: str) -> float:
    """单个字符的宽度（以字号为单位）。"""
    if ch == "\t":
        return 2.0
    return 1.0 if unicodedata.east_asian_width(ch) in _WIDE_EAW else 0.5


def wrap_text(text: str, width_in: float, font_pt: float) -> List[str]:
    """把一段文本按指定宽度折行，返回行列表。"""
    limit = max(4.0, width_in * 72.0 / (max(font_pt, 1.0) * _CHAR_MARGIN))
    lines: List[str] = []
    for para in text.split("\n"):
        para = para.rstrip()
        if not para:
            lines.append("")
            continue
        buf, cur = "", 0.0
        for ch in para:
            w = char_width(ch)
            if buf and cur + w > limit:
                lines.append(buf)
                buf, cur = ch, w
            else:
                buf += ch
                cur += w
        if buf:
            lines.append(buf)
    return lines or [""]


def estimate_lines(text: str, width_in: float, font_pt: float) -> int:
    """估算一段文字在给定宽度下会占几行。"""
    return len(wrap_text(text, width_in, font_pt))


_RE_BRACKET_NUM = re.compile(r"^[（(]\s*[一二三四五六七八九十\d]+\s*[）)]\s*")
_RE_SCORE_TAIL = re.compile(
    r"[（(][^（）()]{0,40}(?:共\s*\d+\s*小?题|\d+\s*分|满分)[^（）()]{0,20}[）)]"
)
# 「阅读下面的文字，完成1～4题」里的尾巴
_RE_TASK_TAIL = re.compile(r"[，,、]?\s*完成[^，,。]{0,16}?[题问]\s*$")
# 「下面的文字」「下列材料」这类冗词，去掉后标签更短更干净
_RE_BELOW = re.compile(r"(?:下[面列]|以下).*$")


def clean_title(title: str) -> str:
    """把标题洗成人能看、能当标签用的短名字。

    「（二）阅读Ⅱ（本题共4小题，18分）」      → 「阅读Ⅱ」
    「一、阅读下面的文字，完成1～4题」          → 「阅读」
    「一、选择题：本题共15小题，每小题3分……」  → 「选择题」
    """
    t = (title or "").strip()
    t = re.sub(r"^[一二三四五六七八九十]+\s*、\s*", "", t)
    t = _RE_BRACKET_NUM.sub("", t)
    t = _RE_SCORE_TAIL.sub("", t)
    t = t.strip("（）() 　")
    before = t
    t = _RE_TASK_TAIL.sub("", t).strip("，,、 ")
    t = _RE_BELOW.sub("", t).strip("，,、 的")
    t = t.strip("（）() 　")
    if len(t) < 2:                 # 洗没了就退回上一步的结果
        t = before
    return t or (title or "").strip()


def tidy_answer(text: str) -> str:
    """答案文本清理：去掉多余的空白与前导换行。

    用 split_rich 逐行处理，理科公式里的上下标格式才不会在这一步丢掉。
    """
    if not text:
        return ""
    from .richtext import rich_concat, split_rich

    lines = [ln.strip() for ln in split_rich(text, "\n")]
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()
    out = ""
    for i, ln in enumerate(lines):
        out = rich_concat(out, "\n" if i else "", ln)
    return out
