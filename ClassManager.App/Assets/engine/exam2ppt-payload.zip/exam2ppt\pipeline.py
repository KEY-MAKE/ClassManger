# -*- coding: utf-8 -*-
"""转换流水线的中间层：命令行（main.py）和图形界面（gui.py）都调用这里。

把「认文件 → 解析 → 排版 → 落盘」这一串步骤收敛到一个函数里，
避免两个入口各写一份逻辑、日后改一处漏一处。
"""

import json
import os
import re
import tempfile
import tempfile
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Tuple

from .builder import build, extract_background
from .parser import merge, parse_answers, parse_exam, read_paragraphs

# 解析文档的识别标记。
# 「【2题答案】」「【18（1）题详解】」这类带题号的写法在「纯答案版」里最常见，
# 必须算进去——否则这份文件会被判成 0 分，反过来把试题当成解析文档给换掉。
RE_ANSWER_MARK = re.compile(
    r"[【\[]\s*(答案|解析|导语|详解)\s*[】\]]|\d+\s*题(?:答案|解析|详解)|参考答案")


@dataclass
class ConvertResult:
    """一次转换的结果，供界面展示。"""
    ok: bool = False
    out_path: str = ""
    slides: int = 0
    questions: int = 0
    sections: List[Tuple[str, int, int, int]] = field(default_factory=list)
    missing: List[int] = field(default_factory=list)
    message: str = ""


# --------------------------------------------------------------------------
# 文件识别
# --------------------------------------------------------------------------
def answer_score(path: str) -> int:
    """数一数文档里【答案】/【解析】这类标记有多少，用来判断哪份是解析文档。"""
    try:
        paras = read_paragraphs(path)
    except Exception:
        return 0
    return sum(1 for t, _ in paras[:600] if RE_ANSWER_MARK.search(t))


def check_docx(path: str) -> Optional[str]:
    """校验文件是否可用，返回错误说明（None 表示没问题）。"""
    if not path:
        return "没有选择文件"
    if not os.path.exists(path):
        return "文件不存在：{}".format(path)
    if not path.lower().endswith((".docx", ".docm")):
        return "只支持 .docx 格式（旧版 .doc 请先用 Word/WPS 另存为 .docx）"
    return None


def detect_roles(path_a: str, path_b: str) -> Tuple[str, str, bool]:
    """判断两份文件哪份是试题、哪份是解析，返回 (试题, 解析, 是否交换过)。"""
    sa, sb = answer_score(path_a), answer_score(path_b)
    if sa > 3 and sa > sb:
        return path_b, path_a, True
    return path_a, path_b, False


# --------------------------------------------------------------------------
# 解析
# --------------------------------------------------------------------------
def parse_pair(exam_path: str, answer_path: str, assets: Optional[str] = None,
               log: Optional[Callable[[str], None]] = None,
               trust_roles: bool = False):
    """解析两份文档，返回 (exam, bank, 错误说明)。

    trust_roles=True 表示调用者已经明确指定了哪份是试题、哪份是解析
    （命令行用 --exam/--answer，界面上是分别选的文件），此时不再自动交换。
    自动交换只该用在「拖进来两个文件、顺序不确定」的场景。
    """
    def say(msg):
        if log:
            log(msg)

    err = check_docx(exam_path) or check_docx(answer_path)
    if err:
        return None, None, err

    if trust_roles:
        swapped = False
    else:
        exam_path, answer_path, swapped = detect_roles(exam_path, answer_path)
        if swapped:
            say("（检测到两份文件顺序颠倒，已自动交换）")
    say("试题：{}".format(os.path.basename(exam_path)))
    say("解析：{}".format(os.path.basename(answer_path)))

    say("[1/4] 读取答案解析文档…")
    bank = parse_answers(answer_path)
    if not bank.qnos():
        say("！警告：没找到【答案】/【解析】/【N题详解】标记，"
            "请确认它确实是对应试卷的答案解析。")
    say("      命中 答案 {} 题 / 解析 {} 题 / 导语 {} 处".format(
        len(bank.answers), len(bank.analyses), len(bank.guides)))

    say("[2/4] 读取试题原卷…")
    # 从 Word 里抠出来的插图只是排版中间产物，放系统临时目录，别污染工程目录
    img_dir = os.path.join(tempfile.gettempdir(), "exam2ppt_images")
    exam = parse_exam(exam_path, known_qnos=bank.qnos(), image_dir=img_dir)
    merge(exam, bank)
    say("      识别 大题 {} 个 / 材料组 {} 组 / 题目 {} 道".format(
        len(exam.sections), sum(len(s.groups) for s in exam.sections),
        len(exam.all_questions())))
    return exam, bank, None


def save_structure(exam, bank, json_path: str):
    """把解析出的结构写成 JSON，方便人工核对切分是否正确。"""
    d = os.path.dirname(os.path.abspath(json_path))
    if d:
        os.makedirs(d, exist_ok=True)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(_to_json(exam, bank), f, ensure_ascii=False, indent=2)
    return json_path


def dump_structure(exam_path: str, answer_path: str, json_path: str,
                   assets: Optional[str] = None,
                   log: Optional[Callable[[str], None]] = None) -> ConvertResult:
    """只解析、只导出 JSON，不生成 PPT。用在界面的「预览解析结构」按钮上。"""
    res = ConvertResult()
    exam, bank, err = parse_pair(exam_path, answer_path, assets=assets, log=log)
    if err:
        res.message = err
        return res
    if not exam.all_questions():
        res.message = "没能识别出任何题目，请确认选的是试题原卷。"
        return res
    save_structure(exam, bank, json_path)
    res.ok = True
    res.out_path = json_path
    res.questions = len(exam.all_questions())
    res.missing = [q.number for q in exam.all_questions()
                   if not q.answer and not q.analysis]
    return res


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def convert(exam_path: str, answer_path: str,
            out_path: Optional[str] = None,
            template: Optional[str] = None,
            assets: Optional[str] = None,
            skip_material: bool = False,
            skip_guide: bool = False,
            skip_analysis: bool = False,
            skip_answer: bool = False,
            dump_json: Optional[str] = None,
            log: Optional[Callable[[str], None]] = None,
            progress: Optional[Callable[[int, int], None]] = None,
            should_cancel: Optional[Callable[[], bool]] = None,
            trust_roles: bool = False) -> ConvertResult:
    """把两份 Word 合成一份讲评课件，返回 ConvertResult。

    log(msg)                 输出一行进度信息
    progress(done, total)    排版进度回调（用于进度条）
    should_cancel()          返回 True 时中断生成
    trust_roles              两份文件已由调用者明确指定，不要自动交换
    """
    def say(msg):
        if log:
            log(msg)

    res = ConvertResult()
    exam, bank, err = parse_pair(exam_path, answer_path, assets=assets, log=say,
                                 trust_roles=trust_roles)
    if err:
        res.message = err
        return res

    questions = exam.all_questions()
    if not questions:
        res.message = ("没能从试题文档里识别出任何题目。\n"
                       "请确认选的是「试题原卷」（而不是答案卷）；"
                       "或先用「预览解析结构」导出 JSON 核对切分。")
        return res

    res.questions = len(questions)
    res.missing = [q.number for q in questions if not q.answer and not q.analysis]
    if res.missing:
        say("      注意：第 {} 题没匹配到答案或解析（不影响出题，只是缺内容）".format(
            res.missing))

    if dump_json:
        save_structure(exam, bank, dump_json)
        say("      结构已导出：{}".format(dump_json))

    if should_cancel and should_cancel():
        res.message = "已取消"
        return res

    # ---------- 3. 准备素材 ----------
    say("[3/4] 准备版式素材…")
    base = assets or os.path.join(os.path.dirname(os.path.abspath(exam_path)), ".cache")
    bg = None
    if template:
        if template.lower().endswith(".pptx"):
            bg = extract_background(template, base)
            say("      已从模板提取背景图" if bg else "      模板里没找到背景图")
        else:
            say("      背景模板不是 .pptx，已忽略")
    if not bg:
        for cand in ("slide_bg.png", "slide_bg.jpeg", "slide_bg.jpg"):
            p = os.path.join(base, cand)
            if os.path.exists(p):
                bg = p
                break
    say("      背景图：{}".format(os.path.basename(bg) if bg else "未找到，使用纯白背景"))

    # ---------- 4. 生成 PPTX ----------
    if not out_path:
        out_path = os.path.splitext(exam_path)[0] + "（讲评课件）.pptx"
    say("[4/4] 排版生成…")

    def on_progress(done, total, qno):
        if progress:
            progress(done, total)
        if should_cancel and should_cancel():
            raise KeyboardInterrupt

    try:
        path, n = build(exam, out_path, bg=bg,
                        skip_material=skip_material,
                        skip_guide=skip_guide,
                        skip_analysis=skip_analysis,
                        skip_answer=skip_answer,
                        on_log=say, on_progress=on_progress)
    except KeyboardInterrupt:
        res.message = "已取消"
        return res
    except PermissionError:
        res.message = ("写不进去：{}\n"
                       "这个文件可能正在 PowerPoint 里打开着，请先关掉再试。").format(out_path)
        return res

    res.ok = True
    res.out_path = path
    res.slides = n
    res.sections = [(s.title, min(q.number for q in s.questions),
                     max(q.number for q in s.questions), len(s.questions))
                    for s in exam.sections]
    return res


def _to_json(exam, bank):
    return {
        "title": exam.title,
        "subtitle": exam.subtitle,
        "sections": [
            {
                "title": s.title,
                "groups": [
                    {
                        "title": g.title,
                        "material_chars": len(g.material),
                        "material_note": g.material_note,
                        "guide": g.guide,
                        "images": len(g.images),
                        "questions": [
                            {
                                "number": q.number,
                                "section": q.section,
                                "group": q.group,
                                "stem": q.stem,
                                "extra": q.extra,
                                "options": [{"label": o.label, "text": o.text}
                                            for o in q.options],
                                "answer": q.answer,
                                "answer_letters": q.answer_letters,
                                "analysis": q.analysis,
                            }
                            for q in g.questions
                        ],
                    }
                    for g in s.groups
                ],
            }
            for s in exam.sections
        ],
        "answer_bank": {
            "answers": {str(k): v for k, v in sorted(bank.answers.items())},
            "analysis_keys": sorted(bank.analyses),
            "guide_keys": sorted(bank.guides),
        },
    }
