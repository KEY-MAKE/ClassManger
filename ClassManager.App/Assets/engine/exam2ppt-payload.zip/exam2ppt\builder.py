# -*- coding: utf-8 -*-
"""PPTX 生成：把解析后的结构排版成讲评课件。

版式规则复刻自样例课件：
  · 内容页铺一张浅色圆点背景图，左上角红色细边框标签（「阅读Ⅱ原题」）；
  · 题目页的白色圆角题卡里是**完整的题目**：题干、材料、**插图**、小问、选项，
    全部按原文顺序排下来（插图内联在原位，不会被丢到单独一页）；
  · 题卡下方贴底悬浮一块米色渐变的缺角矩形（plaque）答案面板，里面是【答案】+【解析】；
  · 面板贴在**题目最后一页**——题目跨页时才是「题目讲完 → 点一下 → 出答案」；
  · 面板带**单击进入动画**：讲课时题目先出来，点一下答案才淡入并自下方浮起。
"""

import os
import re
import zipfile
from typing import List, Optional, Sequence, Tuple

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml import parse_xml
from pptx.oxml.ns import nsdecls, qn
from pptx.util import Inches, Pt

from .models import Exam, Question
from .richtext import Rich, rich_concat, slice_rich, split_rich
from .textutil import clean_title, estimate_lines, tidy_answer, wrap_text
from . import theme as T

_PLAQUE = getattr(MSO_SHAPE, "PLAQUE", MSO_SHAPE.ROUNDED_RECTANGLE)


# ==========================================================================
# 底层绘制工具
# ==========================================================================
def _set_ea(run, name: str):
    """同时设置西文与东亚字体，保证中文也用指定字体渲染。"""
    rPr = run._r.get_or_add_rPr()
    latin = rPr.find(qn("a:latin"))
    ea = rPr.find(qn("a:ea"))
    if ea is None:
        ea = rPr.makeelement(qn("a:ea"), {})
        if latin is not None:
            latin.addnext(ea)
        else:
            rPr.append(ea)
    ea.set("typeface", name)
    cs = rPr.find(qn("a:cs"))
    if cs is None:
        cs = rPr.makeelement(qn("a:cs"), {})
        ea.addnext(cs)
    cs.set("typeface", name)


def _apply_font(run, style: dict):
    f = run.font
    f.size = Pt(style.get("size", 18))
    f.bold = bool(style.get("bold", False))
    f.color.rgb = style.get("color", T.INK)
    name = style.get("font", T.FONT_BODY)
    f.name = name
    _set_ea(run, name)


def _soft_shadow(shape, alpha=18000):
    """给形状加一层很淡的外阴影（模板里的卡片就是这种质感）。"""
    spPr = shape._element.spPr
    for e in spPr.findall(qn("a:effectLst")):
        spPr.remove(e)
    xml = (
        '<a:effectLst %s><a:outerShdw blurRad="63500" dist="25400" dir="5400000" '
        'rotWithShape="0"><a:srgbClr val="000000"><a:alpha val="%d"/>'
        "</a:srgbClr></a:outerShdw></a:effectLst>" % (nsdecls("a"), alpha)
    )
    spPr.append(parse_xml(xml))


def _set_bg(slide, img_path: Optional[str]):
    """把图片铺成整页背景。"""
    if not img_path or not os.path.exists(img_path):
        return
    _, rId = slide.part.get_or_add_image_part(img_path)
    xml = (
        "<p:bg %s><p:bgPr><a:blipFill rotWithShape=\"1\">"
        '<a:blip r:embed="%s"/><a:stretch><a:fillRect/></a:stretch>'
        "</a:blipFill><a:effectLst/></p:bgPr></p:bg>" % (nsdecls("p", "a", "r"), rId)
    )
    cSld = slide._element.find(qn("p:cSld"))
    cSld.insert(0, parse_xml(xml))


SCRIPT_SCALE = 0.66        # 上下标字号占正文的比例（PowerPoint 里 baseline 不会自动缩字）


def _add_runs(p, text, style):
    """往段落里加文字。

    普通字符串就是一个 run；`Rich`（理科公式）会按 `.segs` 拆成多个 run，
    上下标用 `baseline` 属性抬高/压低——这是 PowerPoint 原生能力，
    比拿 Unicode 上标字符去凑要准得多。
    """
    segs = getattr(text, "segs", None)
    if not segs:
        r = p.add_run()
        r.text = text
        _apply_font(r, style)
        return
    base = style.get("size", 18)
    small = max(8, int(round(base * SCRIPT_SCALE)))
    for chunk, kind in segs:
        r = p.add_run()
        r.text = chunk
        st = style
        if kind:
            st = dict(style)
            st["size"] = small
        _apply_font(r, st)
        if kind:
            r._r.get_or_add_rPr().set(
                "baseline", "30000" if kind == "sup" else "-25000")


def _fill_tf(tf, paras, wrap=True):
    """往任意 text_frame（文本框或自选图形）里填段落。

    paras: [ (runs, opts), ... ]，runs: [(text, style), ...]
    """
    tf.word_wrap = wrap
    tf.auto_size = MSO_AUTO_SIZE.NONE
    for i, (runs, opts) in enumerate(paras):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = opts.get("align", PP_ALIGN.LEFT)
        # 用「固定磅值」而不是「倍数」设置行距：倍数值取决于字体的自然行高
        # （中文字体往往 1.2~1.3 倍），无法精确预估，会导致内容溢出卡片。
        ls = opts.get("line_spacing", 1.25)
        sizes = [st.get("size", 18) for _, st in runs] or [18]
        p.line_spacing = Pt(max(sizes) * ls)
        p.space_after = Pt(opts.get("space_after", 0))
        p.space_before = Pt(opts.get("space_before", 0))
        for text, st in runs:
            _add_runs(p, text, st)
    return tf


def _textbox(slide, x, y, w, h, paras, anchor=MSO_ANCHOR.TOP, wrap=True):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    _fill_tf(tf, paras, wrap)
    return tb


def _rect(slide, shape, x, y, w, h, fill=None, line=None, line_w=1.25,
          shadow=False, adj=None):
    sh = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    if adj is not None:
        try:
            sh.adjustments[0] = adj
        except Exception:
            pass
    if fill is None:
        sh.fill.background()
    else:
        sh.fill.solid()
        sh.fill.fore_color.rgb = fill
    if line is None:
        sh.line.fill.background()
    else:
        sh.line.color.rgb = line
        sh.line.width = Pt(line_w)
    sh.shadow.inherit = False
    if shadow:
        _soft_shadow(sh)
    tf = sh.text_frame
    tf.word_wrap = False
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    return sh


def _shape_text(sh, text, style, align=PP_ALIGN.CENTER):
    p = sh.text_frame.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = text
    _apply_font(r, style)


def _blank(prs):
    return prs.slides.add_slide(prs.slide_layouts[6])


def _tag_width(text: str) -> float:
    return min(6.4, max(3.1, len(text) * 0.30 + 0.7))


def _add_tag(slide, text: str):
    sh = _rect(slide, MSO_SHAPE.RECTANGLE, T.TAG_X, T.TAG_Y,
               _tag_width(text), T.TAG_H, fill=None, line=T.RED_DARK, line_w=1.5)
    _shape_text(sh, text, {"size": T.SIZE_TAG, "color": T.RED_DARK,
                           "font": T.FONT_STEM})


def _add_card(slide, x=T.CARD_X, y=T.CARD_Y, w=T.CARD_W, h=T.CARD_H,
              fill=T.CARD):
    return _rect(slide, MSO_SHAPE.ROUNDED_RECTANGLE, x, y, w, h,
                 fill=fill, line=None, shadow=True, adj=0.03)


def _content_slide(prs, bg, tag):
    s = _blank(prs)
    _set_bg(s, bg)
    _add_tag(s, tag)
    return s


# ==========================================================================
# 答案面板：贴底悬浮 + 单击浮现
# ==========================================================================
def _blocks_height(blocks, width_in: float) -> float:
    """估算 _blocks() 结构的文字总高度（英寸）。"""
    total = 0.0
    for runs, opts in blocks:
        ls = opts.get("line_spacing", 1.25)
        for text, st in runs:
            size = st.get("size", 18)
            total += estimate_lines(text, width_in, size) * size * ls / 72.0
    return total


def _add_answer_panel(slide, x, y, w, h, paras):
    """答案面板：米色渐变的缺角矩形（自带底图质感）+ 内嵌答案/解析文字。

    文字直接写进图形自己的文本框，整个面板就是**一个形状**——
    这样加进入动画时只需要引用一个 spid，timing XML 最简单也最不容易出错。
    """
    sh = slide.shapes.add_shape(_PLAQUE, Inches(x), Inches(y), Inches(w), Inches(h))
    try:
        sh.adjustments[0] = 0.05
    except Exception:
        pass
    try:
        fill = sh.fill
        fill.gradient()
        stops = fill.gradient_stops
        stops[0].color.rgb = T.CREAM_TOP
        stops[0].position = 0.0
        stops[1].color.rgb = T.CREAM_BOTTOM
        stops[1].position = 1.0
        try:
            fill.gradient_angle = 90.0
        except Exception:
            pass
    except Exception:
        sh.fill.solid()
        sh.fill.fore_color.rgb = T.CREAM_TOP
    sh.line.color.rgb = T.BROWN
    sh.line.width = Pt(1.0)
    sh.shadow.inherit = False
    _soft_shadow(sh, alpha=30000)          # 投影重一点，突出「浮起来」的感觉

    tf = sh.text_frame
    # 内容明显比面板矮时（答案只有「故选 C」一行，面板却有个最小高度），
    # 让文字居中——贴着顶会让下面那截米色看着像漏了内容。
    avail = h - 2 * T.PANEL_PAD_Y
    tf.vertical_anchor = (MSO_ANCHOR.MIDDLE
                          if _blocks_height(paras, w - 2 * T.PANEL_PAD_X)
                          < avail * 0.82 else MSO_ANCHOR.TOP)
    tf.margin_left = tf.margin_right = Inches(T.PANEL_PAD_X)
    tf.margin_top = tf.margin_bottom = Inches(T.PANEL_PAD_Y)
    _fill_tf(tf, paras)
    return sh


def _animate_on_click(slide, shape, duration=520, float_up=True):
    """给形状加「单击时淡入、自下方浮起」的进入动画。

    python-pptx 没有动画 API，这里按 DrawingML 的 <p:timing> 结构手工拼 XML。
    结构就是 PowerPoint 给「淡出 + 上浮」生成的那一套：
      p:set 让形状变为可见 → p:animEffect fade 淡入 → p:anim ppt_y 从下方滑上来。
    """
    spid = shape.shape_id

    motion = ""
    if float_up:
        motion = (
            '<p:anim calcmode="lin" valueType="num"><p:cBhvr additive="base">'
            '<p:cTn id="8" dur="{dur}" fill="hold"/>'
            '<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl>'
            '<p:attrNameLst><p:attrName>ppt_y</p:attrName></p:attrNameLst>'
            "</p:cBhvr><p:tavLst>"
            '<p:tav tm="0"><p:val><p:strVal val="#ppt_y+0.07"/></p:val></p:tav>'
            '<p:tav tm="100000"><p:val><p:strVal val="#ppt_y"/></p:val></p:tav>'
            "</p:tavLst></p:anim>"
        ).format(dur=duration, spid=spid)

    xml = (
        '<p:timing {ns}>'
        '<p:tnLst><p:par>'
        '<p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot">'
        "<p:childTnLst><p:seq concurrent=\"1\" nextAc=\"seek\">"
        '<p:cTn id="2" dur="indefinite" nodeType="mainSeq"><p:childTnLst>'
        '<p:par><p:cTn id="3" fill="hold">'
        '<p:stCondLst><p:cond delay="indefinite"/></p:stCondLst>'
        "<p:childTnLst><p:par>"
        '<p:cTn id="4" fill="hold">'
        '<p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst><p:par>'
        '<p:cTn id="5" presetID="10" presetClass="entr" presetSubtype="0" '
        'fill="hold" grpId="0" nodeType="clickEffect">'
        '<p:stCondLst><p:cond delay="0"/></p:stCondLst><p:childTnLst>'
        "<p:set><p:cBhvr>"
        '<p:cTn id="6" dur="1" fill="hold">'
        '<p:stCondLst><p:cond delay="0"/></p:stCondLst></p:cTn>'
        '<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl>'
        "<p:attrNameLst><p:attrName>style.visibility</p:attrName></p:attrNameLst>"
        '</p:cBhvr><p:to><p:strVal val="visible"/></p:to></p:set>'
        '<p:animEffect transition="in" filter="fade"><p:cBhvr>'
        '<p:cTn id="7" dur="{dur}"/>'
        '<p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl>'
        "</p:cBhvr></p:animEffect>"
        "{motion}"
        "</p:childTnLst></p:cTn></p:par>"
        "</p:childTnLst></p:cTn></p:par></p:childTnLst></p:cTn></p:par>"
        "</p:childTnLst></p:cTn>"
        '<p:prevCondLst><p:cond evt="onPrev" delay="0">'
        "<p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:prevCondLst>"
        '<p:nextCondLst><p:cond evt="onNext" delay="0">'
        "<p:tgtEl><p:sldTgt/></p:tgtEl></p:cond></p:nextCondLst>"
        "</p:seq></p:childTnLst></p:cTn></p:par></p:tnLst></p:timing>"
    ).format(ns=nsdecls("p", "a"), spid=spid, dur=duration, motion=motion)

    sld = slide._element
    for old in sld.findall(qn("p:timing")):
        sld.remove(old)
    # <p:sld> 的子元素顺序是 cSld → clrMapOvr → transition → timing → extLst
    anchor = sld.find(qn("p:clrMapOvr"))
    if anchor is None:
        anchor = sld.find(qn("p:cSld"))
    anchor.addnext(parse_xml(xml))


def _est_height(paras, width_in: float, line_spacing: float, gap: float = 0.0) -> float:
    """估算若干段落排下来需要多高（英寸）。"""
    total = 0.0
    for text, st in paras:
        size = st.get("size", 18)
        n = estimate_lines(text, width_in, size) if text else 1
        total += n * size * line_spacing / 72.0 + gap
    return total


# ==========================================================================
# 各类页面
# ==========================================================================
def _slide_cover(prs, exam: Exam):
    s = _blank(prs)
    subject = (exam.subtitle or "").strip()
    label = "{} · 真题解析".format(subject) if subject else "真题解析"
    _textbox(s, 0.95, 0.60, 8.6, 0.7,
             [([(label, {"size": T.SIZE_COVER_SUB, "bold": True,
                         "font": T.FONT_TITLE, "color": T.INK})],
               {"align": PP_ALIGN.LEFT})])
    _rect(s, MSO_SHAPE.RECTANGLE, 0.98, 1.30, 2.4, 0.045, fill=T.RED_DARK)

    title = exam.title or "试卷讲评"
    # 样例封面主标题是 60pt；标题太长时逐级收小，避免顶到两侧或折成三行
    size = (T.SIZE_COVER if len(title) <= 26
            else (48 if len(title) <= 36 else 40))
    _textbox(s, 0.90, 2.40, 11.55, 2.2,
             [([(title, {"size": size, "bold": True, "font": T.FONT_TITLE,
                         "color": T.RED_TITLE})], {"align": PP_ALIGN.CENTER,
                                                   "line_spacing": 1.25})])
    _textbox(s, 0.90, 4.45, 11.55, 0.9,
             [([("讲 评 课 件", {"size": 24, "font": T.FONT_TITLE,
                                 "color": T.GRAY})], {"align": PP_ALIGN.CENTER})])
    _rect(s, MSO_SHAPE.RECTANGLE, 0.0, 7.34, T.SLIDE_W_IN, 0.16, fill=T.CREAM_NAV)
    return s


def _slide_toc(prs, exam: Exam, bg):
    items = [clean_title(s.title) for s in exam.sections]
    per_page = 6
    slides = []
    for chunk_no in range(0, len(items), per_page):
        chunk = items[chunk_no:chunk_no + per_page]
        s = _content_slide(prs, bg, "目 录")
        y = 1.30
        for i, name in enumerate(chunk, start=chunk_no + 1):
            chip = _rect(s, MSO_SHAPE.ROUNDED_RECTANGLE, 1.35, y, 1.05, 0.66,
                         fill=T.GOLD, line=None, adj=0.22)
            _shape_text(chip, "{:02d}".format(i),
                        {"size": T.SIZE_TOC_NO, "bold": True,
                         "color": RGBColor(0xFF, 0xFF, 0xFF),
                         "font": T.FONT_UI})
            # 样例这里用「方正北魏楷书_GBK」，属商业字体、系统普遍没装，
            # 换成一定自带的楷体，观感最接近
            _textbox(s, 2.75, y - 0.10, 8.0, 0.90,
                     [([(name, {"size": T.SIZE_TOC_ITEM, "font": T.FONT_BODY,
                                "color": T.INK})],
                       {"align": PP_ALIGN.LEFT})], anchor=MSO_ANCHOR.MIDDLE)
            y += 0.95
        _rect(s, MSO_SHAPE.RECTANGLE, 10.85, 1.30, 1.6, 4.9, fill=T.CREAM_NAV)
        _textbox(s, 10.85, 1.30, 1.6, 4.9,
                 [([("目", {"size": T.SIZE_TOC_TITLE, "bold": True,
                            "font": T.FONT_TITLE, "color": T.NAVY})],
                   {"align": PP_ALIGN.CENTER}),
                  ([("录", {"size": T.SIZE_TOC_TITLE, "bold": True,
                            "font": T.FONT_TITLE, "color": T.NAVY})],
                   {"align": PP_ALIGN.CENTER})],
                 anchor=MSO_ANCHOR.MIDDLE)
        slides.append(s)
    return slides


def _slide_section(prs, title: str, label="真题解析"):
    s = _blank(prs)
    _textbox(s, 1.05, 0.66, 8.6, 0.7,
             [([(label, {"size": T.SIZE_COVER_SUB, "bold": True,
                         "font": T.FONT_TITLE, "color": T.INK})],
               {"align": PP_ALIGN.LEFT})])
    _rect(s, MSO_SHAPE.RECTANGLE, 1.08, 1.42, 2.4, 0.045, fill=T.RED_DARK)
    name = clean_title(title)
    # 样例章节大标题是 96pt
    size = (T.SIZE_SECTION if len(name) <= 14
            else (72 if len(name) <= 20 else 56))
    _textbox(s, 0.90, 2.60, 11.55, 2.3,
             [([(name, {"size": size, "bold": True, "font": T.FONT_TITLE,
                        "color": T.RED_TITLE})], {"align": PP_ALIGN.CENTER})])
    return s


def _slide_text_pages(prs, bg, tag, text, font_pt, font, color, x=T.TEXT_X,
                      y=T.TEXT_Y, w=T.TEXT_W, h=T.TEXT_H, line_spacing=1.45,
                      prefix=None, prefix_style=None):
    """通用的「整段文字 + 自动分页」幻灯片。

    分页以「自然段」为单位，交给 PowerPoint 自己做换行——这样不会有
    「半行 + 一个句号」这类难看的碎行；只有单个自然段本身就超过一页时，
    才退化成按行硬切。
    """
    paras = []
    if prefix:
        paras.append((prefix, dict(prefix_style or {"size": font_pt, "bold": True,
                                                    "color": color, "font": font})))
    for ln in split_rich(text or "", "\n"):
        paras.append((ln, {"size": font_pt, "color": color, "font": font}))
    pages = _paginate_paragraphs(paras, w, h, line_spacing, split_sentences=True)
    out = []
    for idx, page in enumerate(pages):
        s = _content_slide(prs, bg, tag)
        # 卡片按内容收高：内容少时不要留一大片空白白卡
        used = _page_height(page, w, line_spacing)
        card_h = min(T.CARD_FULL_BOTTOM - T.CARD_Y,
                     max(T.CARD_MIN_H, used + 2 * T.PAD_Y + 0.12))
        _add_card(s, y=T.CARD_Y, h=card_h)
        blocks = [([(t, style)], {"align": PP_ALIGN.LEFT, "line_spacing": line_spacing})
                  for t, style in page]
        _textbox(s, x, y, w, h, blocks)
        if len(pages) > 1:
            _page_no(s, idx + 1, len(pages))
        out.append(s)
    return out


def _page_no(slide, i, n):
    """页码放在右上角——右下角会与贴底的答案面板撞车。"""
    _textbox(slide, 11.55, 0.26, 1.48, 0.32,
             [([("{}/{}".format(i, n), {"size": T.SIZE_PAGENO,
                                        "color": T.GRAY,
                                        "font": T.FONT_UI})], {"align": PP_ALIGN.RIGHT})])


def _slide_images(prs, bg, tag, images: Sequence[str]):
    out = []
    step = 2
    for i in range(0, len(images), step):
        chunk = images[i:i + step]
        s = _content_slide(prs, bg, tag)
        _add_card(s)
        n = len(chunk)
        slot_w = T.TEXT_W / n
        for j, path in enumerate(chunk):
            try:
                pic = s.shapes.add_picture(path, Inches(0), Inches(0))
            except Exception:
                continue
            max_w = Inches(slot_w * 0.92)
            max_h = Inches(T.TEXT_H * 0.96)
            scale = min(max_w / pic.width, max_h / pic.height, 3.0)
            pic.width = int(pic.width * scale)
            pic.height = int(pic.height * scale)
            left = T.TEXT_X + slot_w * j + (slot_w - pic.width / 914400.0) / 2
            pic.left = Inches(left)
            pic.top = Inches(T.TEXT_Y + (T.TEXT_H - pic.height / 914400.0) / 2)
        out.append(s)
    return out


Q_SPACING = 1.32            # 题目行距倍数（样例实测约 1.5~2.0，取偏紧的一档）
A_SPACING = 1.44            # 答案/解析行距倍数


def _answer_paras(q: Question, skip_analysis: bool,
                  skip_answer: bool = False,
                  size: int = T.SIZE_ANSWER) -> List[Tuple[str, dict]]:
    """答案 + 解析，合并成同一块——这就是底部悬浮面板里的内容。

    skip_answer=True 时整块都不要，题目页就没有答案面板（用来出学生版）。
    """
    paras: List[Tuple[str, dict]] = []
    if skip_answer:
        return paras
    ans = tidy_answer(q.answer)
    if q.is_choice and q.answer_letters:
        paras.append(("【答案】" + "".join(q.answer_letters),
                      {"size": size, "bold": True, "color": T.RED_DARK,
                       "font": T.FONT_UI}))
    elif ans:
        paras.append(("【答案】", {"size": size, "bold": True,
                                  "color": T.RED_DARK, "font": T.FONT_UI}))
        for ln in split_rich(ans, "\n"):
            paras.append((ln, {"size": size, "color": T.INK,
                               "font": T.FONT_UI}))
    if not skip_analysis:
        ana = tidy_answer(q.analysis)
        if ana:
            paras.append(("【解析】", {"size": size, "bold": True,
                                      "color": T.PURPLE, "font": T.FONT_UI}))
            for ln in split_rich(ana, "\n"):
                paras.append((ln, {"size": size, "color": T.PURPLE,
                                   "font": T.FONT_UI}))
    return paras


def _page_height(page, width_in, spacing, gap=0.0):
    """估算一页内容排下来实际需要多高（英寸）。"""
    total = 0.0
    for text, st in page:
        size = st.get("size", T.SIZE_STEM)
        total += (estimate_lines(text, width_in, size) * size * spacing / 72.0
                  + gap)
    return total


def _blocks(page, spacing):
    return [([(t, style)], {"align": PP_ALIGN.LEFT, "line_spacing": spacing})
            for t, style in page]


IMG_MAX_H = 3.4             # 题目页里单张插图的最大高度
IMG_GAP = 0.14              # 插图与上下文字之间的间距
IMG_MIN_PX = 40             # 小于这个尺寸的多半是行内符号，不是插图，丢弃


def _img_display(path, max_w, max_h):
    """图片等比缩放到 max_w × max_h 内的显示尺寸（英寸）；太小就丢弃。"""
    try:
        from pptx.parts.image import Image as PptxImage
        pw, ph = PptxImage.from_file(path).size
    except Exception:
        return None
    if not pw or not ph or min(pw, ph) < IMG_MIN_PX:
        return None
    ratio = float(ph) / float(pw)
    w, h = max_w, max_w * ratio
    if h > max_h:
        h, w = max_h, max_h / ratio
    return w, h


def _question_flow(q: Question, width: float, max_img_h: float):
    """把题目按**原文顺序**排成一条流：[('text'|'image', 内容, 高度, 样式)]

    关键点：插图是题目的一部分，必须插在它原本出现的位置（题干下面、某段材料中间、
    两个小问之间），而不是被丢到单独一页。图片位置由解析阶段记录的 image_after 决定。
    """
    stem_style = {"size": T.SIZE_STEM, "color": T.INK, "font": T.FONT_STEM,
                  "bold": True}
    body_style = {"size": T.SIZE_STEM, "color": T.INK, "font": T.FONT_STEM}

    def text_h(text, st):
        n = estimate_lines(text, width, st["size"])
        return n * st["size"] * Q_SPACING / 72.0 + 0.04

    flow = [("text", q.stem, text_h(q.stem, stem_style), stem_style)]

    by_index = {}
    for idx, imgs in q.image_after:
        by_index.setdefault(idx, []).extend(imgs)

    def add_images(idx):
        for path in by_index.get(idx, []):
            size = _img_display(path, width, max_img_h)
            if size:
                flow.append(("image", path, size[1] + IMG_GAP, size))

    add_images(0)                       # 紧跟题干后面的图
    for i, line in enumerate(q.extra):
        if line:
            flow.append(("text", line, text_h(line, body_style), body_style))
        add_images(i + 1)               # 这一段之后的图

    # 选项放在最后（选项一律不标红——答案要留到单击之后才揭晓）。
    # 字体和字号跟题干一致：样例讲评课件里选项就是和题干同一个文本框、同一字体。
    opt_style = {"size": T.SIZE_STEM, "color": T.INK, "font": T.FONT_STEM}
    opt_lines = [rich_concat(op.label + ". ", op.text) for op in q.options]
    # 理科选择题的选项常常只有几个字符（「A. {1}  B. {1,2}」），
    # 原卷就是挤在一行里的。若整行放得下就照原样排一行，别硬拆成四行、白占三行高度。
    if len(opt_lines) >= 2:
        joined = ""
        for i, ln in enumerate(opt_lines):
            joined = rich_concat(joined, "" if i == 0 else "    ", ln)
        if estimate_lines(joined, width, T.SIZE_STEM) == 1:
            opt_lines = [joined]
    for line in opt_lines:
        flow.append(("text", line, text_h(line, opt_style), opt_style))
    return flow


def _paginate_flow(flow, width: float, page_h: float):
    """把「文字 + 图片」的流按高度分页，尽量保持图片完整不跨页。"""
    pages, cur, used = [], [], 0.0

    def flush():
        nonlocal cur, used
        if cur:
            pages.append(cur)
        cur, used = [], 0.0

    for item in flow:
        kind, payload, h, meta = item

        if h > page_h and kind == "text":
            # 单段就超过一整页：按行硬切（图片已限高，走不到这里）
            flush()
            lh = meta["size"] * Q_SPACING / 72.0
            for ln in wrap_text(payload, width * 0.96, meta["size"]):
                if cur and used + lh > page_h:
                    flush()
                cur.append(("text", ln, lh, meta))
                used += lh
            continue

        if cur and used + h > page_h:
            if kind == "text":
                lh = meta["size"] * Q_SPACING / 72.0
                cut = _split_for_fit(payload, width, meta["size"],
                                     page_h - used, lh)
                if cut:
                    head, tail = cut
                    cur.append(("text", head,
                                estimate_lines(head, width, meta["size"]) * lh + 0.04,
                                meta))
                    flush()
                    cur.append(("text", tail,
                                estimate_lines(tail, width, meta["size"]) * lh + 0.04,
                                meta))
                    used = estimate_lines(tail, width, meta["size"]) * lh + 0.04
                    continue
            flush()

        cur.append(item)
        used += h
    flush()
    return pages or [[]]


def _flow_height(page, width):
    """估算一段「文字 + 插图」流排下来实际占多高（口径与 _draw_flow 完全一致）。"""
    total = 0.0
    for kind, payload, _h, meta in page:
        if kind == "text":
            total += (estimate_lines(payload, width, meta["size"]) * meta["size"]
                      * Q_SPACING / 72.0 + 0.04)
        else:
            total += meta[1] + IMG_GAP
    return total


def _draw_flow(slide, x, y, width, page):
    """按顺序把一页里的文字和插图画出来，返回实际占用高度。

    连续的文字段落会**合并进同一个文本框**，交给 PowerPoint 自己连续排版；
    只有遇到插图才断开。否则每段一个小文本框，一旦行数估多了，
    段与段之间就会露出空档（表现成「选项 C 和 D 之间莫名空一行」）。
    """
    cy = y
    i, n = 0, len(page)
    while i < n:
        kind, payload, _h, meta = page[i]

        if kind == "image":
            iw, ih = meta
            slide.shapes.add_picture(
                payload, Inches(x + (width - iw) / 2.0), Inches(cy),
                width=Inches(iw), height=Inches(ih))
            cy += ih + IMG_GAP
            i += 1
            continue

        batch = []                      # 收集连续的文字段落
        while i < n and page[i][0] == "text":
            batch.append(page[i])
            i += 1
        total = 0.0
        blocks = []
        for _, text, _hh, st in batch:
            total += (estimate_lines(text, width, st["size"]) * st["size"]
                      * Q_SPACING / 72.0 + 0.04)
            blocks.append(([(text, st)], {"align": PP_ALIGN.LEFT,
                                          "line_spacing": Q_SPACING}))
        _textbox(slide, x, cy, width, total + 0.16, blocks)
        cy += total
    return cy - y


def _plan_question(q, skip_analysis, skip_answer, q_w, a_w, avail):
    """挑一个最省版面、又尽量把答案留在题目页的排法。

    两条路线：

      **A 面板路线**：题目占上半页，答案面板贴底悬浮（单击才浮现）。
        面板给得高 → 答案一屏放完，但题目被挤成多页；
        面板给小   → 题目舒展，但答案要接续页。

      **B 分开路线**：题目独占整页，答案自己一页。
        样例讲评课件就是这么做的——翻它的稿子能看到一批「只有解析、没有题目」的页。
        当题目和答案都很长时，硬留在同一页会把题目切成「原题 + 原题·续」，
        再多一个「答案·续」，一题占三页，还不如干脆分开。

    答案字号也在 20~24pt 之间试一遍（样例自己就在这个区间浮动）。

    打分顺序：总页数 → 面板有没有「只塞下两行、剩下全靠续页」→ 答案占几页
              → 有面板优先 → 字号大优先 → 面板高度。

    最后一项「面板高度」在两种情况下方向相反：装得下时越矮越好——答案很短时
    （理科选择题常常只有一行「故选 C」），撑满半页只会让学生以为漏了内容；
    装不下时越高越好——面板里多放一行，续页就能少一行。

    那个「溢出」项很关键：面板高度小于答案所需时，面板里会只剩【答案】【解析】
    两行、正文全被推到「答案·续」，比干脆分成题干页 + 答案页还难看。
    所以只要答案装不进面板，就宁可走分开路线。
    """
    # 没有答案（学生版、或这道题本来就没配答案）：题目独占整页
    has_ans = (bool(q.answer_letters) or bool(tidy_answer(q.answer))
               or (not skip_analysis and bool(tidy_answer(q.analysis))))
    if skip_answer or not has_ans:
        cap = T.CARD_FULL_BOTTOM - T.CARD_TOP - T.CARD_PAD
        flow = _question_flow(q, q_w, min(IMG_MAX_H, max(0.8, cap - 0.3)))
        return 0.0, T.SIZE_ANSWER, _paginate_flow(flow, q_w, cap), None, []

    full_h = (T.CARD_FULL_BOTTOM - T.CARD_TOP) - 2 * T.PANEL_PAD_Y - 0.16
    q_cap_full = T.CARD_FULL_BOTTOM - T.CARD_TOP - T.CARD_PAD
    best = None

    def offer(score, ha, size, q_pages, panel_page, a_pages):
        nonlocal best
        if best is None or score < best[0]:
            best = (score, ha, size, q_pages, panel_page, a_pages)

    for size in T.ANSWER_SIZES:
        a_paras = _answer_paras(q, skip_analysis, False, size)
        if not a_paras:
            break

        # ---------- A：面板贴在题目末页 ----------
        # 注意这里的 0.24 必须比下面的 0.16 大：面板里真正能用的是
        # ha - 2*PAD - 0.16，若按 0.10 算「刚好装下」，实际会差 0.06in 装不下，
        # 于是永远被判成溢出，只能退到更大的候选面板——答案很短时面板就会虚胖。
        need = (_est_height(a_paras, a_w, A_SPACING, 0.03)
                + 2 * T.PANEL_PAD_Y + 0.24)
        want = min(max(need, T.PANEL_MIN), T.PANEL_MAX)
        cands = sorted({round(x, 2) for x in
                        (want, T.PANEL_MAX, T.PANEL_MAX * 0.78,
                         T.PANEL_MAX * 0.56, T.PANEL_MAX * 0.36, T.PANEL_MIN)
                        if T.PANEL_MIN <= x <= T.PANEL_MAX}, reverse=True)
        for ha in cands:
            q_cap = avail - ha
            if q_cap < T.CARD_TEXT_MIN:           # 题目至少要留这么多
                continue
            flow = _question_flow(q, q_w, min(IMG_MAX_H, max(0.8, q_cap - 0.3)))
            q_pages = _paginate_flow(flow, q_w, q_cap)

            small_h = max(0.40, ha - 2 * T.PANEL_PAD_Y - 0.16)
            chunks = _paginate_paragraphs(a_paras, a_w, small_h, A_SPACING,
                                          gap=0.03, split_sentences=True)
            rest = [p for pg in chunks[1:] for p in pg]
            a_pages = (_paginate_paragraphs(rest, a_w, full_h, A_SPACING,
                                            gap=0.03, split_sentences=True)
                       if rest else [])
            # 面板高度的取舍要看装不装得下：
            #   装得下 → 越矮越好（贴合内容，别留一片空白米色）；
            #   装不下 → 越高越好（面板里能多放一行，续页就少一行）。
            offer((len(q_pages) + len(a_pages), 1 if rest else 0,
                   len(a_pages), 0, -size, -ha if rest else ha),
                  ha, size, q_pages, chunks[0], a_pages)

        # ---------- B：题目独占整页，答案单独成页 ----------
        flow = _question_flow(q, q_w, min(IMG_MAX_H, max(0.8, q_cap_full - 0.3)))
        q_pages = _paginate_flow(flow, q_w, q_cap_full)
        a_pages = _paginate_paragraphs(a_paras, a_w, full_h, A_SPACING,
                                       gap=0.03, split_sentences=True)
        offer((len(q_pages) + len(a_pages), 0, len(a_pages), 1, -size, 0.0),
              0.0, size, q_pages, None, a_pages)

    if best is None:                              # 兜底
        size = T.ANSWER_SIZES[-1]
        a_paras = _answer_paras(q, skip_analysis, False, size)
        flow = _question_flow(q, q_w, min(IMG_MAX_H, max(0.8, q_cap_full - 0.3)))
        q_pages = _paginate_flow(flow, q_w, q_cap_full)
        a_pages = _paginate_paragraphs(a_paras, a_w, full_h, A_SPACING,
                                       gap=0.03, split_sentences=True)
        return 0.0, size, q_pages, None, a_pages

    _, ha, size, q_pages, panel_page, a_pages = best
    return ha, size, q_pages, panel_page, a_pages


def _slide_question(prs, bg, name: str, q: Question, skip_analysis: bool = False,
                    skip_answer: bool = False):
    """题目 + 答案放在同一页：

    白色题卡里是**完整的题目**——题干、材料、插图、小问、选项，按原文顺序排下来，
    题目太长就接「原题·续」；答案面板贴在**题目最后一页**的下方，单击才淡入浮现。

    为什么面板放最后一页而不是第一页：题目跨页时，若把答案放在第 1 页，
    上课的节奏会变成「材料 → 答案 → 剩下的题 → 更多答案」，很乱。
    放在最后一页才是「题目讲完 → 点一下 → 出答案」。

    题目和答案都长到塞不进一页时，`_plan_question` 会改走「题干页 + 答案页」，
    此时 ha 为 0：题目独占整页，答案另起一页——样例讲评课件也是这么排的。
    """
    q_w = T.TEXT_W - 0.04                     # 估算与分页用同一个宽度，避免多切一页
    a_w = T.PANEL_W - 2 * T.PANEL_PAD_X
    avail = T.PANEL_BOTTOM - T.PANEL_GAP - (T.CARD_TOP + T.CARD_PAD)

    ha, ans_size, q_pages, panel_page, a_pages = _plan_question(
        q, skip_analysis, skip_answer, q_w, a_w, avail)

    n_total = len(q_pages) + len(a_pages)
    out, seq = [], [0]

    def stamp(slide):
        seq[0] += 1
        if n_total > 1:
            _page_no(slide, seq[0], n_total)

    # ---- 逐页画：面板只贴在题目的最后一页 ----
    last_idx = len(q_pages) - 1
    for i, page in enumerate(q_pages):
        tag = "{}原题".format(name) if i == 0 else "{}原题·续".format(name)
        s = _content_slide(prs, bg, tag)
        with_panel = ha > 0 and i == last_idx
        if with_panel:
            panel_top = T.PANEL_BOTTOM - ha
            card_bottom = panel_top + T.PANEL_OVERLAP
        else:
            # 没有面板的页：卡片贴着内容收，别把半页白卡晾在那儿
            used = _flow_height(page, q_w)
            card_bottom = min(T.CARD_FULL_BOTTOM,
                              T.CARD_TOP + max(T.CARD_MIN_H,
                                               used + 2 * T.CARD_PAD))
        _add_card(s, y=T.CARD_TOP, h=max(1.0, card_bottom - T.CARD_TOP))
        _draw_flow(s, T.TEXT_X, T.CARD_TOP + T.CARD_PAD, q_w, page)
        if with_panel:
            panel = _add_answer_panel(s, T.PANEL_X, panel_top, T.PANEL_W, ha,
                                      _blocks(panel_page, A_SPACING))
            _animate_on_click(s, panel)       # ← 单击才浮现
        stamp(s)
        out.append(s)

    # ---- 答案自己的页：面板自带底图，同样单击才浮现 ----
    full_h = T.CARD_FULL_BOTTOM - T.CARD_TOP
    for i, page in enumerate(a_pages):
        if ha > 0:
            tag = "{}答案·续".format(name)     # 面板没放下、溢出来的部分
        else:
            tag = ("{}答案解析".format(name) if i == 0
                   else "{}答案解析·续".format(name))
        s = _content_slide(prs, bg, tag)
        # 面板按内容收高（留个下限），别撑满整页只剩一片米色
        used = _page_height(page, a_w, A_SPACING, 0.03)
        h = min(full_h, max(2.2, used + 2 * T.PANEL_PAD_Y + 0.10))
        sh = _add_answer_panel(s, T.PANEL_X, T.CARD_TOP, T.PANEL_W, h,
                               _blocks(page, A_SPACING))
        _animate_on_click(s, sh)
        stamp(s)
        out.append(s)

    return out


_RE_SENT_END = re.compile(r"(?<=[。！？；])")


def _split_for_fit(text, width_in, size, height_in, line_h):
    """把一段话切成 (前半, 后半)，让前半尽量塞满 height_in。

    整段放不下时，若直接把它推到下一页，当前页就会留下一大片空白
    （答案面板尤其明显）。这里同时算两种切法，取填得更满的那个：

      · **句子级**：在句号/问号/分号处断开，读起来最自然；
      · **行级**：按行硬切，能把剩余空间吃干净，但末行可能略短。

    句子级能填满时优先用它；填不满就退到行级，宁可末行短一点也别留空。
    """
    if height_in <= line_h * 0.5:
        return None

    best = None

    parts = [p for p in _RE_SENT_END.split(text) if p]
    if len(parts) > 1:
        head = ""
        for i, piece in enumerate(parts):
            cand = head + piece
            n = estimate_lines(cand, width_in, size)
            if n * line_h > height_in:
                if head:
                    best = ("".join(parts[:i]), "".join(parts[i:]),
                            estimate_lines(head, width_in, size))
                break
            head = cand

    # 按行硬切：宽度再收 6%，防止拼回去后被 PowerPoint 二次换行
    max_lines = int(height_in // line_h)
    if max_lines >= 1:
        lines = wrap_text(text, width_in * 0.94, size)
        if len(lines) > max_lines:
            tight = ("".join(lines[:max_lines]), "".join(lines[max_lines:]),
                     max_lines)
            if best is None or tight[2] > best[2]:
                best = tight

    if not best:
        return None
    head, tail = best[0], best[1]
    if isinstance(text, Rich) and len(head) + len(tail) == len(text):
        # head + tail 就是原文，按长度回切就能把公式的上下标格式带过去
        return (slice_rich(text, 0, len(head)),
                slice_rich(text, len(head), len(text)))
    return head, tail


def _paginate_paragraphs(paras, width_in, height_in, line_spacing=1.35, gap=0.0,
                         split_sentences=False):
    """按自然段分页。

    每段高度 = 估算行数 × 行高，段与段之间留 gap 英寸。
    split_sentences=True 时，塞不下的整段会先尝试在句子边界切开填满当前页
    （答案面板靠它消除底部空白）；题目页不要开——选项被拦腰截断会很难读。
    单段自身就超过一整页时，退化成按行硬切。
    """
    pages, cur, used = [], [], 0.0

    def flush():
        nonlocal cur, used
        if cur:
            pages.append(cur)
        cur, used = [], 0.0

    def place(text, st):
        nonlocal used
        size = st.get("size", 18)
        line_h = size * st.get("line_spacing", line_spacing) / 72.0
        remain = text
        guard = 0
        while remain and guard < 200:
            guard += 1
            need = estimate_lines(remain, width_in, size) * line_h + gap
            if need > height_in:
                # 这一段自身就超过一整页：按行硬切。打 4% 折扣，避免硬切出来的
                # 行被 PowerPoint 二次换行、甩出一个孤零零的句号。
                for ln in wrap_text(remain, width_in * 0.96, size):
                    if cur and used + line_h > height_in:
                        flush()
                    cur.append((ln, st))
                    used += line_h
                return
            if not cur or used + need <= height_in:
                cur.append((remain, st))
                used += need
                return
            if split_sentences:
                cut = _split_for_fit(remain, width_in, size,
                                     height_in - used, line_h)
                if cut:
                    head, tail = cut
                    cur.append((head, st))
                    used += estimate_lines(head, width_in, size) * line_h + gap
                    flush()
                    remain = tail
                    continue
            flush()

    for text, st in paras:
        place(text, st)
    flush()
    return pages or [[]]


# ==========================================================================
# 主流程
# ==========================================================================
def build(exam: Exam, out_path: str, bg: Optional[str] = None,
          skip_material: bool = False, skip_guide: bool = False,
          skip_analysis: bool = False, skip_answer: bool = False,
          on_log=None, on_progress=None):
    """生成 PPTX 并返回 (路径, 幻灯片数)。

    on_progress(done, total, qno) 会在每道题开始排版时回调，界面据此画进度条。
    """
    log = on_log or (lambda *a: None)
    prs = Presentation()
    prs.slide_width = Inches(T.SLIDE_W_IN)
    prs.slide_height = Inches(T.SLIDE_H_IN)

    _slide_cover(prs, exam)
    _slide_toc(prs, exam, bg)

    total = max(1, len(exam.all_questions()))
    done = 0

    for sec in exam.sections:
        _slide_section(prs, sec.title)
        for g in sec.groups:
            name = _short_name(g.title)
            if not skip_material and (g.material or g.material_note):
                text = g.material
                if g.material_note:
                    text = rich_concat(text, "\n" if text else "",
                                       g.material_note)
                _slide_text_pages(prs, bg, "{}材料".format(name), text,
                                  T.SIZE_MATERIAL, T.FONT_BODY, T.INK,
                                  line_spacing=1.5)
            if g.images:
                _slide_images(prs, bg, "{}材料图".format(name), g.images)
            if not skip_guide and g.guide:
                _slide_text_pages(prs, bg, "{}导语".format(name), g.guide,
                                  T.SIZE_GUIDE, T.FONT_BODY, T.PURPLE,
                                  line_spacing=1.5,
                                  prefix="【导语】",
                                  prefix_style={"size": T.SIZE_GUIDE,
                                                "bold": True, "color": T.PURPLE,
                                                "font": T.FONT_BODY})
            for q in g.questions:
                if on_progress:
                    on_progress(done, total, q.number)
                log("  排版第 {} 题（{}）".format(
                    q.number, "选择题" if q.is_choice else "非选择题"))
                _slide_question(prs, bg, name, q,
                                skip_analysis=skip_analysis,
                                skip_answer=skip_answer)
                done += 1

    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    prs.core_properties.title = exam.title or "试卷讲评课件"
    prs.core_properties.comments = "由 exam2ppt 自动生成（纯规则算法，无 AI 模型）"
    prs.save(out_path)
    return out_path, len(prs.slides._sldIdLst)


def _short_name(title: str, limit: int = 12) -> str:
    name = clean_title(title)
    return name[:limit] if len(name) > limit else name


# ==========================================================================
# 从模板里抽取背景图
# ==========================================================================
def extract_background(template_path: str, out_dir: str) -> Optional[str]:
    """从模板 pptx 中找到内容页使用的背景图并导出。"""
    if not template_path or not os.path.exists(template_path):
        return None
    os.makedirs(out_dir, exist_ok=True)
    try:
        with zipfile.ZipFile(template_path) as z:
            names = set(z.namelist())
            slides = sorted(
                [n for n in names if re.match(r"^ppt/slides/slide\d+\.xml$", n)],
                key=lambda n: int(re.findall(r"\d+", os.path.basename(n))[0]),
            )
            best = None
            for sn in slides:
                xml = z.read(sn).decode("utf-8", "ignore")
                m = re.search(r"<p:bg>.*?r:embed=\"(rId\d+)\"", xml, re.S)
                if not m:
                    continue
                rels = "ppt/slides/_rels/" + os.path.basename(sn) + ".rels"
                if rels not in names:
                    continue
                rx = z.read(rels).decode("utf-8", "ignore")
                m2 = re.search(r'Id="%s"[^>]*Target="([^"]+)"' % m.group(1), rx)
                if not m2:
                    continue
                target = os.path.normpath(
                    os.path.join("ppt/slides", m2.group(1))
                ).replace("\\", "/")
                if target not in names:
                    continue
                best = target
                break
            if not best:
                return None
            ext = os.path.splitext(best)[1] or ".png"
            out = os.path.join(out_dir, "slide_bg" + ext)
            with open(out, "wb") as f:
                f.write(z.read(best))
            return out
    except Exception:
        return None
