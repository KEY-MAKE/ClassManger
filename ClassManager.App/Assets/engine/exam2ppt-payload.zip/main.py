#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""exam2ppt 命令行入口。

用法示例
--------
    python main.py 原卷.docx 答案.docx

    # 指定输出与模板
    python main.py --exam 原卷.docx --answer 答案.docx --template 讲评课件.pptx

    # 打开图形界面（不熟悉命令行的老师用这个）
    python main.py --gui

    # 只看解析结果，不生成 PPT
    python main.py --exam 原卷.docx --answer 答案.docx --dump-json 结构.json
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from exam2ppt import __version__
from exam2ppt.pipeline import convert


def _prepare_stdout():
    """Windows 控制台自己会用 WriteConsoleW 输出中文，不需要也不该强行改编码；
    只有输出被重定向到文件时才切成 UTF-8，避免 cp936 下丢字符。"""
    for stream in (sys.stdout, sys.stderr):
        try:
            if stream is not None and not stream.isatty():
                stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def main(argv=None):
    _prepare_stdout()
    ap = argparse.ArgumentParser(
        prog="exam2ppt",
        description="把「试题 Word」+「解析 Word」自动合成为讲评课件 PPTX（纯规则算法，不依赖 AI 模型）",
    )
    ap.add_argument("files", nargs="*", help="两份 docx：试题与解析（顺序不限，程序会自动识别）")
    ap.add_argument("--exam", "-e", help="试题原卷 docx（如：真题（原卷版）.docx）")
    ap.add_argument("--answer", "-a", help="答案解析 docx（如：真题+答案.docx）")
    ap.add_argument("--out", "-o", default=None, help="输出 pptx 路径，默认与试题同目录同名")
    ap.add_argument("--template", "-t", default=None,
                    help="参考模板 pptx：只用它来提取背景图，不影响内容")
    ap.add_argument("--assets", default=None, help="背景图/临时图片目录，默认 ./.cache")
    ap.add_argument("--no-material", action="store_true", help="不生成阅读材料页")
    ap.add_argument("--no-guide", action="store_true", help="不生成【导语】页")
    ap.add_argument("--no-analysis", action="store_true",
                    help="答案面板里不写【解析】，只留【答案】")
    ap.add_argument("--no-answer", action="store_true",
                    help="题目页完全不出现答案面板（用来出学生版）")
    ap.add_argument("--dump-json", default=None, help="把解析出的结构另存为 JSON，便于核对")
    ap.add_argument("--gui", action="store_true", help="打开图形界面")
    ap.add_argument("--quiet", "-q", action="store_true", help="安静模式")
    ap.add_argument("--version", action="version", version="exam2ppt " + __version__)
    args = ap.parse_args(argv)

    # ---------- 图形界面 ----------
    if args.gui or (not args.files and not args.exam):
        initial = list(args.files)
        if args.exam:
            initial.append(args.exam)
        if args.answer:
            initial.append(args.answer)
        try:
            from gui import launch
        except ImportError as exc:
            print("[错误] 无法启动图形界面：{}".format(exc))
            if "tkinter" in str(exc).lower():
                print("       当前 Python 没有带 tkinter（有些精简版/嵌入式版会裁掉它）。")
                print("       两个办法：")
                print("         1) 换用官方 Python（自带 tkinter）：https://www.python.org/downloads/")
                print("         2) 直接用命令行：python main.py 原卷.docx 答案.docx")
            return 4
        launch(initial, assets=args.assets, template=args.template)
        return 0

    # ---------- 命令行 ----------
    exam_path, answer_path = args.exam, args.answer
    # 用 --exam/--answer 明确点名时，就别再自作聪明去猜谁是谁了
    trust = bool(args.exam and args.answer)
    if len(args.files) >= 2:
        exam_path = exam_path or args.files[0]
        answer_path = answer_path or args.files[1]
    elif len(args.files) == 1:
        exam_path = exam_path or args.files[0]

    if not exam_path or not answer_path:
        ap.error("需要提供两份文档：试题 docx 与解析 docx\n"
                 "  例如：python main.py 原卷.docx 答案.docx\n"
                 "  或：  python main.py --gui")

    def log(*a):
        if not args.quiet:
            print(*a)

    res = convert(
        exam_path, answer_path,
        out_path=args.out, template=args.template, assets=args.assets,
        skip_material=args.no_material, skip_guide=args.no_guide,
        skip_analysis=args.no_analysis, skip_answer=args.no_answer,
        dump_json=args.dump_json,
        log=log,
        trust_roles=trust,
    )

    if not res.ok:
        print("[错误] {}".format(res.message or "生成失败"))
        return 3

    print("")
    print("完成：{}".format(res.out_path))
    print("共 {} 页幻灯片，主题结构：".format(res.slides))
    for title, lo, hi, n in res.sections:
        print("  · {:<24} 第 {}-{} 题（{} 题）".format(title, lo, hi, n))
    if res.missing:
        print("  未匹配到答案/解析的题：{}".format(res.missing))
    return 0


if __name__ == "__main__":
    sys.exit(main())
