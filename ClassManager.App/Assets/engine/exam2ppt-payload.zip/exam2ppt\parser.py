# -*- coding: utf-8 -*-
"""Word 文档纯算法解析。

设计原则
--------
1. 只依赖段落纯文本 + 少量正则，不做任何语义模型推断；
2. 结构识别靠「状态机 + 序号递增校验」，避免把正文里形如 "一、" "B." 的
   内容误判成标题或选项；
3. 题目号的最终裁决权交给解析文档（【N题详解】/【答案】里出现的题号），
   这样即使原卷漏编号，也能正确切分。
"""

import os
import re
import tempfile
from typing import List, Optional, Set, Tuple

from docx import Document
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph

from .models import AnswerBank, Exam, Group, Option, Question, Section
from .omml import para_text
from .richtext import Rich, rich_concat, slice_rich

# --------------------------------------------------------------------------
# 正则规则
# --------------------------------------------------------------------------
CN_NUM = "一二三四五六七八九十"

RE_TOP_SEC = re.compile(r"^([" + CN_NUM + r"]+)\s*、\s*(\S.*)$")
RE_SUB_SEC = re.compile(r"^[（(]([" + CN_NUM + r"]+)[）)]\s*(\S.*)$")
# 题号与选项后面的分隔符：常规是「.」「．」「、」，也容忍「)」「）」
SEC_SEP = r"[.．、)）]"
RE_QNUM = re.compile(r"^(\d{1,2})\s*" + SEC_SEP + r"\s*(.*)$")
RE_OPT_START = re.compile(r"^([A-H])\s*" + SEC_SEP)

# 试卷头里这些行不是「试卷名/科目」，要跳过
RE_HEADER_SKIP = re.compile(
    r"^(?:绝密|机密|秘密|内部使用)|启用前|^[\s*★☆]+$|^注意事项\s*[:：]?$"
)
# 考生须知式的编号行（「1．答卷前，考生务必将……」），不是题目
RE_SKIP_Q = re.compile(
    r"^(?:答卷前|答题前|考试结束后|回答选择题时|本试卷|注意事项|"
    r"请将答案|将答案|考生务必|作图可先)"
)
# 选项标签前面不能是字母/数字/左括号，否则「(A)」这类交叉引用会被误当成选项
RE_OPT_HEAD = re.compile(r"(?<![A-Za-z0-9(（])")
RE_NOTE = re.compile(r"^[\[【〔]注[\]】〕]|^[（(](?:摘编自|选自|节选自|改编自)")

# 题干特征词：用于识别「原卷里漏掉题号」的题目。
# 刻意收得很紧——必须是「请/试 + 作答动词」或「下列……项」这类强句式，
# 否则材料正文里像「三、桥上为什么要有"房子"？」这种问答句会被误判成题目。
RE_QUESTION_CUE = re.compile(
    r"(下列[^，。？！]{0,24}(?:是|有|中)|"
    r"(?:不|有)(?:正确|恰当|符合|准确)的一项|"
    r"(?:请|试)[^，。？！]{0,12}(?:分析|概括|说明|简述|解释|谈|写|补写|修改|判断|"
    r"找出|列出|概述|赏析|翻译|拟写|拟制|评价|探究)|"
    r"(?:有何|哪些)[^，。？！]{0,8}(?:不同|区别|异同)|"
    r"请[^，。？！]{0,6}作答)"
)

MAX_STEM_LEN = 200          # 无题号题干的最大长度
MAX_SEC_LEN = 50            # 标题行的最大长度


# --------------------------------------------------------------------------
# 基础工具
# --------------------------------------------------------------------------
def _cn_to_int(s: str) -> int:
    """中文数字 → 阿拉伯数字（支持 一 ~ 二十）。"""
    if not s:
        return 0
    if s == "十":
        return 10
    if s.startswith("十"):
        return 10 + CN_NUM.index(s[1]) + 1
    if s.endswith("十"):
        return (CN_NUM.index(s[0]) + 1) * 10
    if "十" in s:
        a, b = s.split("十", 1)
        return (CN_NUM.index(a) + 1) * 10 + (CN_NUM.index(b) + 1)
    return CN_NUM.index(s[0]) + 1


_RE_ZW = re.compile(r"[\u200b-\u200f\ufeff]")


def _norm(t: str) -> str:
    """规范化段落文本：统一全角空格、去掉零宽字符、压缩空白。

    传入带公式的富文本时，逐个分段做同样的处理，最后只裁掉整段两头的空白，
    这样 `a` + 上标`2` 之间的连接不会被误删。
    """
    if isinstance(t, Rich):
        segs = []
        for text, kind in t.segs:
            text = text.replace("\u3000", " ").replace("\xa0", " ")
            segs.append((_RE_ZW.sub("", text), kind))
        return Rich(segs).strip()
    t = t.replace("\u3000", " ").replace("\xa0", " ")
    t = _RE_ZW.sub("", t)
    t = re.sub(r"[ \t]+$", "", t)
    return t.strip()


def read_paragraphs(docx_path: str, image_dir: Optional[str] = None):
    """按文档顺序读出所有段落，返回 [(text, [image_path, ...]), ...]。

    同时把段落里的插图导出到 image_dir，便于后续排版。
    段落里带 Word 原生公式（OMML）时，text 会是 Rich（带上下标分段），
    否则仍是普通 str——对没有公式的文科卷来说，行为和以前完全一样。
    """
    doc = Document(docx_path)
    body = doc.element.body
    out: List[Tuple[str, List[str]]] = []
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            p = Paragraph(child, doc)
            out.append((_norm(para_text(child, p.text)),
                        _extract_images(p, image_dir)))
        elif child.tag == qn("w:tbl"):
            tb = Table(child, doc)
            for row in tb.rows:
                for c in row.cells:
                    parts: List[str] = []
                    for cp in c.paragraphs:
                        parts.append(_norm(para_text(cp._element, cp.text)))
                    txt = ""
                    for i, part in enumerate(parts):
                        txt = rich_concat(txt, "\n" if i else "", part)
                    if txt:
                        out.append((txt, []))
    return out


def _extract_images(paragraph: Paragraph, image_dir: Optional[str]) -> List[str]:
    """导出段落内嵌图片，返回本地文件路径列表。"""
    paths: List[str] = []
    blips = paragraph._element.findall(".//" + qn("a:blip"))
    if not blips:
        return paths
    if image_dir is None:
        image_dir = os.path.join(tempfile.gettempdir(), "exam2ppt_images")
    os.makedirs(image_dir, exist_ok=True)
    for i, blip in enumerate(blips):
        rid = blip.get(qn("r:embed"))
        if not rid:
            continue
        try:
            part = paragraph.part.related_parts[rid]
        except KeyError:
            continue
        ext = os.path.splitext(str(part.partname))[1] or ".png"
        dst = os.path.join(
            image_dir, "img_{}_{}{}".format(abs(hash(rid)) % 100000, i, ext)
        )
        if not os.path.exists(dst):
            with open(dst, "wb") as f:
                f.write(part.blob)
        paths.append(dst)
    return paths


# 大题标题里「。……（19分）」这种尾巴
_RE_TAIL_SCORE = re.compile(r"^\s*[（(]?\s*\d+\s*分\s*[）)]?\s*$")


def _heading_core(text: str):
    """判断这一段能不能当标题：能就返回「标题本体」，不能返回 None。

    真实试卷里，大题标题经常把**说明语挤在同一行**：

        一、选择题：本题共15小题，每小题3分，共45分。在每小题给出的四个选项中……
        二、非选择题：本题共4小题，共55分。

    所以不能拿整段去做长度和标点检查，得先切成「标题本体 + 说明语」：

      · 有冒号 → 冒号前面就是本体（`一、选择题`）；
      · 有句号 → 只接受「一句话 + （N分）」这种尾巴；
      · 都没有 → 本体就是整段。

    同时挡掉正文里的句子：以 ？ ！ 结尾的一律不是标题
    （比如材料里的「四、中国廊桥有什么独特之处？」）。
    """
    if not text:
        return None
    if text[-1] in "？！?!":
        return None

    for sep in ("：", ":"):
        if sep in text:
            core = text.split(sep, 1)[0].strip()
            # 本体必须是短名词短语：太长、带句号、带逗号的都算正文句子
            if core and len(core) <= 24 and "。" not in core and "，" not in core:
                return core
            return None

    if "。" in text:
        head, _, tail = text.partition("。")
        if (text.count("。") == 1 and len(head) <= MAX_SEC_LEN
                and _RE_TAIL_SCORE.match(tail)):
            return head.strip()
        return None

    if text[-1] in "；;，,、":
        return None
    if len(text) > MAX_SEC_LEN:
        return None
    return text


def _is_section_heading(text: str, seen_top: int, seen_sub: int):
    """判断是否为章节标题，返回 (level, number, title, core) 或 None。

    core 是「剥掉说明语」后的标题本体，用来给章节/材料组命名，
    这样「一、选择题：本题共15小题……」在课件上只会显示「选择题」。

    level: 'top' 表示「一、阅读（72分）」；'sub' 表示「（二）阅读Ⅱ」。

    标题和正文里的「一、什么是廊桥？」长得一模一样，只能靠这些约束区分：
      1) 先切成「标题本体」（见 _heading_core）：要么短，要么是名词短语；
      2) 中文序号必须比已见过的**大**——重复或倒退的一律不算标题；
      3) 允许少见地跳号（最多跳 2），这样试卷缺了「（一）」也能继续认下去。
    """
    core = _heading_core(text)
    if not core:
        return None
    m = RE_TOP_SEC.match(core)
    if m:
        num = _cn_to_int(m.group(1))
        if seen_top < num <= seen_top + 3:
            return ("top", num, m.group(2).strip(), core)
        return None
    m = RE_SUB_SEC.match(core)
    if m:
        num = _cn_to_int(m.group(1))
        if seen_sub < num <= seen_sub + 3:
            return ("sub", num, m.group(2).strip(), core)
        return None
    return None


def _looks_like_orphan_question(text: str) -> bool:
    """识别「原卷漏编号」的题干。

    这是本工具唯一一处启发式判断，条件收得很紧：
      1. 段落足够短、以句末标点结尾；
      2. 不长得像章节标题（避免材料里「三、桥上为什么要有房子？」被误伤）；
      3. 含强题干句式（如「请概括说明」「下列……的一项是」）。
    真正切分时还会校验「下一题号必须存在于解析文档中」，双重保险。
    """
    if not text or len(text) > MAX_STEM_LEN:
        return False
    if RE_TOP_SEC.match(text) or RE_SUB_SEC.match(text):
        return False
    if not text.endswith(("？", "。", "）")):
        return False
    return bool(RE_QUESTION_CUE.search(text))


def _split_stem_options(text: str):
    """把「题干和选项挤在同一段」的情况拆开。

    有些卷子写成 `1. 下列说法正确的是（ ）A．甲 B．乙 C．丙 D．丁`，
    这里从第一个 `A．` 处切开，返回 (题干, 选项列表)。
    认不出至少两个选项就不切，原样返回。
    """
    m = re.search(r"(?<![A-Za-z0-9(（])A\s*" + SEC_SEP + r"\s*", text)
    if not m or m.start() == 0:
        return text, []
    opts, _ = _parse_option_chain(slice_rich(text, m.start()), "A")
    if len(opts) < 2:
        return text, []
    return slice_rich(text, 0, m.start()).strip(), opts


def _parse_option_chain(text: str, start_label: str):
    """从一段文本中按字母顺序切出选项。

    支持一行多个选项（如「A. 甲B. 乙」）以及跨段延续（下一段从 C 开始）。
    返回 (options, next_label)。
    """
    labels = "ABCDEFGH"
    if start_label not in labels:
        start_label = "A"
    i = labels.index(start_label)
    out: List[Option] = []
    pos = 0
    while i < len(labels):
        lab = labels[i]
        pat = re.compile(r"(?<![A-Za-z0-9(（])" + lab + r"\s*" + SEC_SEP + r"\s*")
        m = pat.search(text, pos)
        if not m:
            break
        s = m.end()
        i += 1
        nxt = labels[i] if i < len(labels) else None
        e = len(text)
        if nxt:
            m2 = re.compile(r"(?<![A-Za-z0-9(（])" + nxt + r"\s*" + SEC_SEP
                            + r"\s*").search(text, s)
            if m2:
                e = m2.start()
        out.append(Option(lab, slice_rich(text, s, e).strip()))
        pos = s
        if e >= len(text):
            break
    next_label = labels[i] if i < len(labels) else "Z"
    return out, next_label


def _extract_answer_letters(ans: str) -> List[str]:
    """从答案文本里提取选择题正确项字母。"""
    if not ans:
        return []
    m = re.match(r"^\s*([A-H]{1,6})\s*[。．.]?\s*(?:$|[\s（(])", ans)
    if m:
        return list(m.group(1))
    m = re.search(r"故选\s*([A-H]{1,6})", ans)
    if m:
        return list(m.group(1))
    return []


# --------------------------------------------------------------------------
# 试题原卷解析
# --------------------------------------------------------------------------
def parse_exam(docx_path: str, known_qnos: Optional[Set[int]] = None,
               image_dir: Optional[str] = None, debug: bool = False) -> Exam:
    """解析试题原卷 docx，返回 Exam 结构。

    known_qnos：解析文档中出现的题号集合。给了它，就能把原卷里漏编号的
    题目也正确切开，并避免把正文数字误判成题号。
    """
    paras = read_paragraphs(docx_path, image_dir)
    exam = Exam()

    cur_section: Optional[Section] = None
    cur_group: Optional[Group] = None
    cur_q: Optional[Question] = None
    next_opt_label = "A"
    seen_top_num = 0
    seen_sub_num = 0
    last_qno = 0
    header_lines: List[str] = []

    def upcoming_qno() -> int:
        """下一道题应有的题号（全局递增）。"""
        return last_qno + 1

    def close_question():
        nonlocal cur_q, next_opt_label
        cur_q = None
        next_opt_label = "A"

    def start_group(title: str) -> Group:
        nonlocal cur_group, cur_q
        g = Group(title=title)
        cur_section.groups.append(g)
        cur_group = g
        cur_q = None
        return g

    def start_question(num: int, stem: str, images: List[str]) -> Question:
        nonlocal cur_q, next_opt_label, last_qno
        q = Question(number=num, stem=stem)
        if images:
            # 和题号同段的图，位置就是「紧跟题干之后」
            q.image_after.append((0, list(images)))
        q.section = cur_section.title if cur_section else ""
        q.group = cur_group.title if cur_group else ""
        cur_group.questions.append(q)
        cur_q = q
        next_opt_label = "A"
        last_qno = num
        return q

    for text, images in paras:
        # ---------- 1. 章节标题 ----------
        head = _is_section_heading(text, seen_top_num, seen_sub_num)
        if head:
            level, num, _title, core = head
            if level == "top":
                seen_top_num = num
                seen_sub_num = 0
                cur_section = Section(title=core)
                exam.sections.append(cur_section)
                start_group(core)
            else:
                seen_sub_num = num
                # 小节：若当前组还没有任何题目/材料，就把它当作当前组的标题
                if cur_group is not None and not cur_group.questions and not cur_group.material:
                    cur_group.title = core
                else:
                    if cur_section is None:
                        cur_section = Section(title=core)
                        exam.sections.append(cur_section)
                    start_group(core)
            close_question()
            continue

        if not text and not images:
            continue

        # ---------- 2. 题号开头的题目 ----------
        m = RE_QNUM.match(text)
        if m:
            num = int(m.group(1))
            # 按索引切而不是取 group(2)，这样公式的上下标格式才留得住
            stem = slice_rich(text, m.start(2), m.end(2)).strip()
            # 两条通过路径：题号在解析文档里出现过，或者它就是紧接着的下一题
            accept = num == upcoming_qno() or (known_qnos and num in known_qnos)
            if accept and cur_group is not None and not RE_SKIP_Q.match(stem):
                stem, inline = _split_stem_options(stem)
                q = start_question(num, stem, images)
                if inline:
                    # 题干和选项挤在同一段里的情况
                    q.options.extend(inline)
                    next_opt_label = "ABCDEFGH"[len(inline)]
                continue

        # ---------- 3. 选项 ----------
        if cur_q is not None and RE_OPT_START.match(text):
            opts, next_opt_label = _parse_option_chain(text, next_opt_label)
            if opts:
                cur_q.options.extend(opts)
                continue

        # ---------- 4. 漏编号的题目 ----------
        if (cur_q is not None and cur_group is not None
                and _looks_like_orphan_question(text)):
            nxt = upcoming_qno()
            if known_qnos and nxt in known_qnos:
                start_question(nxt, text, images)
                continue

        # ---------- 5. 注释 / 出处 ----------
        if RE_NOTE.match(text):
            if cur_q is not None:
                cur_q.extra.append(text)
            elif cur_group is not None:
                cur_group.material_note = rich_concat(
                    cur_group.material_note,
                    "\n" if cur_group.material_note else "", text)
            continue

        # ---------- 6. 普通正文 ----------
        if cur_group is None:
            # 还没进入正文之前的文件头（试卷名 / 科目）；
            # 「机密★启用前」「注意事项：」这类横幅不是试卷名，跳过
            if (text and len(header_lines) < 3 and len(text) <= 80
                    and not RE_HEADER_SKIP.search(text)):
                header_lines.append(text)
            continue
        if cur_q is not None:
            # 纯图片段落（text 为空）不往 extra 里塞空字符串，
            # 否则题干中间会莫名多出一个空行；图片本身带位置记录下来。
            if text:
                cur_q.extra.append(text)
            if images:
                cur_q.image_after.append((len(cur_q.extra), list(images)))
        else:
            if text:
                cur_group.material = rich_concat(
                    cur_group.material,
                    "\n" if cur_group.material else "", text)
            if images:
                cur_group.images.extend(images)

    if header_lines:
        exam.title = header_lines[0]
        exam.subtitle = header_lines[1] if len(header_lines) > 1 else ""
    exam.sections = [s for s in exam.sections if s.groups and s.questions]
    for s in exam.sections:
        for g in s.groups:
            for q in g.questions:
                q.section = s.title
                q.group = g.title
    return exam


# --------------------------------------------------------------------------
# 解析文档解析
# --------------------------------------------------------------------------
RE_ANS_HEAD = re.compile(r"^\s*[【\[]答案[】\]]\s*(.*)$")
RE_EXP_HEAD = re.compile(r"^\s*[【\[]解析[】\]]\s*(.*)$")
RE_QNO_ANS = re.compile(r"^(\d{1,2})\s*[.．、]\s*[【\[]答案[】\]]\s*(.*)$")
RE_GUIDE = re.compile(r"^[【\[]导语[】\]]\s*(.*)$")
# 也容忍「【18（1）题详解】」这种带小题号的写法，题号取括号前的 18
RE_DETAIL = re.compile(
    r"^[【\[](\d{1,2})\s*(?:[（(][^）)]{1,8}[）)])?\s*题详解[】\]]\s*(.*)$"
)
RE_ANS_TOKENS = re.compile(r"(?:^|[\s\u3000])(\d{1,2})\s*[.．、]\s*")
# 有些人写成「答案1.C 2.B 3.A …」，没有方括号。只有当后面确实跟着
# 两个以上「题号.」时才认，避免把「答案是A」这种句子误判成答案区。
RE_ANS_LOOSE = re.compile(r"^\s*[【\[]?\s*答案\s*[】\]]?\s*[:：]?\s*(.*)$")

# ---------- 「纯答案版」格式 ----------
# 这类文件长这样，一个【答案】标记都没有：
#
#     参考答案
#     1.C
#     2.B
#     ……
#     二、非选择题
#     16.①坚持中国共产党的领导……
#     ②坚持依法行政……
#
# 以前整份答案会被丢掉，课件出来全是没答案的空板。这里的策略是：
# 见到「参考答案」这种独立成行的标题后，**先待定**；下一行如果长得像
# 「1.C」才真正进入宽松模式。一旦文里出现【答案】/【解析】这类结构化标记，
# 立刻退出宽松模式——正常格式永远优先。
RE_LOOSE_HEAD = re.compile(
    r"^\s*(?:参考答案|答案|参考答案与解析|答案与解析|参考答案及解析)"
    r"\s*[:：]?\s*$")
RE_LOOSE_QNO = re.compile(r"^\s*(\d{1,2})\s*[.．、]\s*(\S.*)$")
# 一整行只有「12.D」这种纯字母答案，才是「纯答案版」的铁证
RE_LOOSE_LETTER = re.compile(r"^\s*\d{1,2}\s*[.．、]\s*[A-H]{1,4}\s*$")


def parse_answers(docx_path: str, debug: bool = False) -> AnswerBank:
    """解析「试题+答案」「解析」类 docx，抽出题号 → 答案 / 解析 / 导语。"""
    paras = read_paragraphs(docx_path)
    bank = AnswerBank()

    mode = None            # None / 'answer' / 'explain'
    cur_q: Optional[int] = None
    cur_ans_qno: Optional[int] = None   # 答案区当前正在写的题号
    pending_guide: Optional[str] = None
    last_ans_qno: Optional[int] = None
    loose_head = -1        # 「参考答案」独立标题所在段落号（-1 表示没有）
    loose_mode = False     # 确认是「1.C / 16.①……」这种无标记格式

    # 先判定这份文件到底是不是「纯答案版」：
    #   1) 有独立成行的「参考答案」标题；
    #   2) 标题之后确实出现两行以上「12.D」这种纯字母答案；
    #   3) 全文没有【答案】【解析】【N题详解】这类结构化标记（有就优先走老路）。
    # 三条同时满足才启用，避免把试题里的一句「参考答案」当成分界线。
    for _i, (_t, _) in enumerate(paras):
        if RE_LOOSE_HEAD.match(_t):
            loose_head = _i
            break
    if loose_head >= 0:
        has_struct = any(
            RE_DETAIL.match(t) or RE_ANS_HEAD.match(t)
            or RE_QNO_ANS.match(t) or RE_EXP_HEAD.match(t)
            for t, _ in paras)
        letters = sum(1 for t, _ in paras[loose_head:loose_head + 120]
                      if RE_LOOSE_LETTER.match(t))
        loose_mode = (not has_struct) and letters >= 2

    def add_answer(qno: int, content: str):
        nonlocal last_ans_qno, cur_ans_qno
        content = content.strip()
        if qno in bank.answers:
            bank.answers[qno] = rich_concat(bank.answers[qno], "\n", content)
        else:
            bank.answers[qno] = content
        last_ans_qno = qno
        cur_ans_qno = qno

    def add_analysis(qno: int, content: str):
        content = content.strip()
        if qno in bank.analyses:
            bank.analyses[qno] = rich_concat(bank.analyses[qno], "\n", content)
        else:
            bank.analyses[qno] = content

    def flush_guide():
        """导语先暂存，等遇到第一个「N题详解」再绑定到该题号。"""
        nonlocal pending_guide
        if pending_guide and cur_q is not None:
            bank.guides[cur_q] = pending_guide
            pending_guide = None

    def answer_line(text: str) -> bool:
        """处理答案区的一行：能切出题号就切，切不出就归到「上一题的后继」。"""
        if _consume_answer_line(text, bank, add_answer, last_ans_qno):
            return True
        # 无题号前缀：如「【答案】例文：」之后的正文，应属于下一道题
        if cur_ans_qno is None:
            add_answer((last_ans_qno or 0) + 1, text)
        else:
            add_answer(cur_ans_qno, text)
        return True

    for idx, (text, _) in enumerate(paras):
        if not text:
            continue

        # 文档里偶尔混入大题标题，跳过而不污染答案
        if RE_TOP_SEC.match(text) and len(text) <= MAX_SEC_LEN:
            continue

        # ---------- 「纯答案版」的宽松格式 ----------
        if loose_mode:
            if idx == loose_head:
                continue
            m2 = RE_LOOSE_QNO.match(text)
            # 「1．答卷前，考生务必将……」这种考生须知也长着题号，必须挡掉
            if m2 and 1 <= int(m2.group(1)) <= 99 \
                    and not RE_SKIP_Q.match(m2.group(2)):
                cur_q = None
                cur_ans_qno = int(m2.group(1))
                add_answer(cur_ans_qno, slice_rich(text, m2.start(2)))
                continue
            if cur_ans_qno is not None:
                add_answer(cur_ans_qno, text)
            continue

        m = RE_QNO_ANS.match(text)
        if m:
            mode = "answer"
            cur_q = None
            cur_ans_qno = None
            add_answer(int(m.group(1)), slice_rich(text, m.start(2)))
            continue

        m = RE_ANS_HEAD.match(text)
        if m:
            mode = "answer"
            cur_q = None
            cur_ans_qno = None
            rest = slice_rich(text, m.start(1), m.end(1)).strip()
            if rest:
                answer_line(rest)
            continue

        m = RE_ANS_LOOSE.match(text)
        if m and len(RE_ANS_TOKENS.findall(m.group(1) or "")) >= 2:
            mode = "answer"
            cur_q = None
            cur_ans_qno = None
            answer_line(slice_rich(text, m.start(1), m.end(1)).strip())
            continue

        m = RE_EXP_HEAD.match(text)
        if m:
            flush_guide()
            mode = "explain"
            cur_q = None
            rest = slice_rich(text, m.start(1), m.end(1)).strip()
            if rest:
                qno = _explain_target(bank, last_ans_qno)
                add_analysis(qno, rest)
                cur_q = qno
            continue

        m = RE_GUIDE.match(text)
        if m:
            pending_guide = slice_rich(text, m.start(1), m.end(1)).strip()
            continue

        m = RE_DETAIL.match(text)
        if m:
            cur_q = int(m.group(1))
            mode = "explain"
            flush_guide()
            rest = slice_rich(text, m.start(2), m.end(2)).strip()
            if rest:
                add_analysis(cur_q, rest)
            continue

        # ---------- 续行 ----------
        if mode == "answer":
            answer_line(text)
        elif mode == "explain":
            qno = _explain_target(bank, last_ans_qno)
            if cur_q is None:
                cur_q = qno
                flush_guide()
            add_analysis(cur_q, text)
        # mode is None：文档开头的无用内容，忽略

    return bank


def _explain_target(bank: AnswerBank, last_ans_qno: Optional[int]) -> int:
    """解析内容该挂到哪一题：优先「答案区最后出现的题号」。"""
    if last_ans_qno is not None:
        return last_ans_qno
    if bank.answers:
        return max(bank.answers)
    if bank.analyses:
        return max(bank.analyses)
    return 1


def _consume_answer_line(text: str, bank: AnswerBank, add_answer, last_qno):
    """按题号切分一行答案文本，如「1. A    2. C」→ {1:'A', 2:'C'}。"""
    ms = list(RE_ANS_TOKENS.finditer(text))
    if not ms:
        return False
    for i, m in enumerate(ms):
        qno = int(m.group(1))
        if qno < 1 or qno > 99:
            continue
        s = m.end()
        e = ms[i + 1].start() if i + 1 < len(ms) else len(text)
        add_answer(qno, slice_rich(text, s, e))
    return True


# --------------------------------------------------------------------------
# 合并
# --------------------------------------------------------------------------
def merge(exam: Exam, bank: AnswerBank) -> Exam:
    """把答案 / 解析 / 导语挂到对应题目上。"""
    for sec in exam.sections:
        for g in sec.groups:
            for q in g.questions:
                q.answer = bank.answers.get(q.number, "")
                q.analysis = bank.analyses.get(q.number, "")
                if not q.answer and q.analysis:
                    q.answer = _guess_answer_from_analysis(q)
                q.answer_letters = _extract_answer_letters(q.answer)
                if not q.answer_letters:
                    q.answer_letters = _extract_answer_letters(q.analysis)
            fq = g.first_qno()
            if fq is not None:
                g.guide = bank.guides.get(fq, "")
            for q in g.questions:
                q.guide = g.guide
    return exam


def _guess_answer_from_analysis(q: Question) -> str:
    """答案缺失时，从解析里兜底提取。"""
    m = re.search(r"故\s*选\s*([A-H]{1,6})", q.analysis or "")
    if m:
        return m.group(1)
    parts = [ln for ln in (q.analysis or "").split("\n")
             if re.match(r"^[A-H]\s*[.．、]", ln)]
    if parts:
        wrong = {ln[0] for ln in parts if "错误" in ln}
        right = {ln[0] for ln in parts if re.search(r"正确|符合", ln)}
        cand = right - wrong
        if len(cand) == 1:
            return cand.pop()
    return ""
