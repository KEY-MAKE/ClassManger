# -*- coding: utf-8 -*-
"""数据结构定义。"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class Option:
    """一个选择题选项，label 为 A/B/C/D。"""
    label: str
    text: str


@dataclass
class Question:
    """一道题。"""
    number: int
    stem: str = ""                        # 题干
    options: List[Option] = field(default_factory=list)
    extra: List[str] = field(default_factory=list)   # 题干之后的补充段落（问答文段、观点等）
    # 该题携带的插图： (插在 extra 的第几段之前, [图片本地路径])
    # 0 表示紧跟在题干后面；用这种「带位置」的记法，排版时才能把图插回原位，
    # 而不是丢到单独一页。纯图片段落不会往 extra 里塞空字符串（否则题干中间会多空行）。
    image_after: List[Tuple[int, List[str]]] = field(default_factory=list)

    answer: str = ""                      # 【答案】原文
    answer_letters: List[str] = field(default_factory=list)  # 选择题正确项字母
    analysis: str = ""                    # 【解析】原文
    guide: str = ""                       # 该组材料的【导语】

    section: str = ""                     # 所属大题标题
    group: str = ""                       # 所属小节（材料组）标题

    # ---------- 派生属性 ----------
    @property
    def images(self) -> List[str]:
        """该题所有插图（按原文顺序展平）。"""
        return [p for _, imgs in self.image_after for p in imgs]

    @property
    def is_choice(self) -> bool:
        """是否为选择题（有 2 个以上选项）。"""
        return len(self.options) >= 2

    @property
    def is_multi_choice(self) -> bool:
        return len(self.answer_letters) > 1

    def stem_full(self) -> str:
        """题干 + 补充段落，用于展示。"""
        parts = [self.stem] + [e for e in self.extra if e]
        return "\n".join(p for p in parts if p)

    def options_text(self) -> str:
        return "\n".join("{}. {}".format(o.label, o.text) for o in self.options)


@dataclass
class Group:
    """一个材料组：一段材料 + 该材料下的若干题目。"""
    title: str = ""
    material: str = ""
    material_note: str = ""                # 注释 / 出处
    guide: str = ""                        # 【导语】
    questions: List[Question] = field(default_factory=list)
    images: List[str] = field(default_factory=list)

    def first_qno(self):
        return self.questions[0].number if self.questions else None


@dataclass
class Section:
    """一个大题（或独立小节）。"""
    title: str = ""
    groups: List[Group] = field(default_factory=list)

    @property
    def questions(self):
        out = []
        for g in self.groups:
            out.extend(g.questions)
        return out


@dataclass
class Exam:
    """整份试卷。"""
    title: str = ""
    subtitle: str = ""
    sections: List[Section] = field(default_factory=list)

    def all_questions(self) -> List[Question]:
        return [q for s in self.sections for q in s.questions]

    def qno_set(self):
        return {q.number for q in self.all_questions()}


@dataclass
class AnswerBank:
    """解析文档解析结果：题目号 → 答案 / 解析 / 导语。"""
    answers: Dict[int, str] = field(default_factory=dict)
    analyses: Dict[int, str] = field(default_factory=dict)
    guides: Dict[int, str] = field(default_factory=dict)

    def qnos(self):
        return set(self.answers) | set(self.analyses) | set(self.guides)
